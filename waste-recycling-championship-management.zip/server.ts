import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import * as dotenv from 'dotenv';
import {
  seedDatabase,
  getSchools,
  insertSchool,
  updateSchool,
  deleteSchool,
  getStudents,
  insertStudent,
  updateStudent,
  deleteStudent,
  getEntries,
  insertEntry,
  updateEntry,
  deleteEntry,
  clearAndResetDb,
} from './src/db/helpers.ts';

// Load env vars
dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Auto-seed database on server start disabled to keep database clean
  // try {
  //   await seedDatabase();
  // } catch (error) {
  //   console.error('Initial auto-seeding failed, proceeding...', error);
  // }

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', database: 'connected' });
  });

  // Schools Route handlers
  app.get('/api/schools', async (req, res) => {
    try {
      const data = await getSchools();
      res.json(data);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to fetch schools' });
    }
  });

  app.post('/api/schools', async (req, res) => {
    try {
      const result = await insertSchool(req.body);
      res.status(201).json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to register school' });
    }
  });

  app.put('/api/schools/:id', async (req, res) => {
    try {
      const result = await updateSchool(req.params.id, req.body);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to update school' });
    }
  });

  app.delete('/api/schools/:id', async (req, res) => {
    try {
      await deleteSchool(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to delete school' });
    }
  });

  // Students Route handlers
  app.get('/api/students', async (req, res) => {
    try {
      const data = await getStudents();
      res.json(data);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to fetch students' });
    }
  });

  app.post('/api/students', async (req, res) => {
    try {
      const result = await insertStudent(req.body);
      res.status(201).json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to register student' });
    }
  });

  app.put('/api/students/:id', async (req, res) => {
    try {
      const result = await updateStudent(req.params.id, req.body);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to update student' });
    }
  });

  app.delete('/api/students/:id', async (req, res) => {
    try {
      await deleteStudent(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to delete student' });
    }
  });

  // Entries Route handlers
  app.get('/api/entries', async (req, res) => {
    try {
      const data = await getEntries();
      res.json(data);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to fetch entries' });
    }
  });

  app.post('/api/entries', async (req, res) => {
    try {
      const result = await insertEntry(req.body);
      res.status(201).json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to register entry' });
    }
  });

  app.put('/api/entries/:id', async (req, res) => {
    try {
      const result = await updateEntry(req.params.id, req.body);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to update entry' });
    }
  });

  app.delete('/api/entries/:id', async (req, res) => {
    try {
      await deleteEntry(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to delete entry' });
    }
  });

  // Reset Database Route
  app.post('/api/reset-db', async (req, res) => {
    try {
      await clearAndResetDb();
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message || 'Failed to reset database' });
    }
  });

  // Vite middleware for dev or serving built assets
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
