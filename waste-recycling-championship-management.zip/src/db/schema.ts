import { pgTable, text, doublePrecision } from 'drizzle-orm/pg-core';

// Define schools table
export const schools = pgTable('schools', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  address: text('address').notNull(),
  contactPerson: text('contact_person').notNull(),
  mobile: text('mobile').notNull(),
  email: text('email').notNull(),
  registrationDate: text('registration_date').notNull(),
});

// Define students table
export const students = pgTable('students', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  grade: text('grade').notNull(),
  section: text('section').notNull(),
  gender: text('gender').notNull(),
  schoolId: text('school_id')
    .references(() => schools.id, { onDelete: 'cascade' })
    .notNull(),
  schoolName: text('school_name').notNull(),
  parentMobile: text('parent_mobile').notNull(),
});

// Define entries table
export const entries = pgTable('entries', {
  id: text('id').primaryKey(),
  studentId: text('student_id')
    .references(() => students.id, { onDelete: 'cascade' })
    .notNull(),
  studentName: text('student_name').notNull(),
  schoolId: text('school_id')
    .references(() => schools.id, { onDelete: 'cascade' })
    .notNull(),
  schoolName: text('school_name').notNull(),
  collectionDate: text('collection_date').notNull(),
  paperWeight: doublePrecision('paper_weight').notNull(),
  plasticWeight: doublePrecision('plastic_weight').notNull(),
  totalWeight: doublePrecision('total_weight').notNull(),
  performance: text('performance').notNull(),
});
