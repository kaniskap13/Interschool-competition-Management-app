import { db } from './index.ts';
import { schools, students, entries } from './schema.ts';
import { eq } from 'drizzle-orm';
import { School, Student, CollectionEntry } from '../types.ts';
import { initialSchools, initialStudents, initialEntries } from '../mockData.ts';

// Helper to seed the database if it is empty
export async function seedDatabase() {
  try {
    // Check if schools table is empty
    const existingSchools = await db.select().from(schools).limit(1);
    if (existingSchools.length === 0) {
      console.log('Database is empty. Seeding initial data...');
      
      // Seed schools
      for (const s of initialSchools) {
        await db.insert(schools).values({
          id: s.id,
          name: s.name,
          address: s.address,
          contactPerson: s.contactPerson,
          mobile: s.mobile,
          email: s.email,
          registrationDate: s.registrationDate,
        });
      }

      // Seed students
      for (const s of initialStudents) {
        await db.insert(students).values({
          id: s.id,
          name: s.name,
          grade: s.grade,
          section: s.section,
          gender: s.gender,
          schoolId: s.schoolId,
          schoolName: s.schoolName,
          parentMobile: s.parentMobile,
        });
      }

      // Seed entries
      for (const e of initialEntries) {
        await db.insert(entries).values({
          id: e.id,
          studentId: e.studentId,
          studentName: e.studentName,
          schoolId: e.schoolId,
          schoolName: e.schoolName,
          collectionDate: e.collectionDate,
          paperWeight: e.paperWeight,
          plasticWeight: e.plasticWeight,
          totalWeight: e.totalWeight,
          performance: e.performance,
        });
      }
      console.log('Database successfully seeded with initial data.');
    }
  } catch (error) {
    console.error('Error seeding database:', error);
    throw new Error('Database seeding failed.', { cause: error });
  }
}

// Schools CRUD
export async function getSchools(): Promise<School[]> {
  try {
    const list = await db.select().from(schools);
    return list.map(s => ({
      id: s.id,
      name: s.name,
      address: s.address,
      contactPerson: s.contactPerson,
      mobile: s.mobile,
      email: s.email,
      registrationDate: s.registrationDate,
    }));
  } catch (error) {
    console.error('Database getSchools failed:', error);
    throw new Error('Could not fetch schools from database.', { cause: error });
  }
}

export async function insertSchool(col: School): Promise<School> {
  try {
    const result = await db.insert(schools).values({
      id: col.id,
      name: col.name,
      address: col.address,
      contactPerson: col.contactPerson,
      mobile: col.mobile,
      email: col.email,
      registrationDate: col.registrationDate,
    }).returning();
    return result[0] as School;
  } catch (error) {
    console.error('Database insertSchool failed:', error);
    throw new Error('Could not create school in database.', { cause: error });
  }
}

export async function updateSchool(id: string, col: Partial<School>): Promise<School> {
  try {
    const result = await db.update(schools)
      .set({
        name: col.name,
        address: col.address,
        contactPerson: col.contactPerson,
        mobile: col.mobile,
        email: col.email,
        registrationDate: col.registrationDate,
      })
      .where(eq(schools.id, id))
      .returning();
    return result[0] as School;
  } catch (error) {
    console.error('Database updateSchool failed:', error);
    throw new Error('Could not update school in database.', { cause: error });
  }
}

export async function deleteSchool(id: string): Promise<void> {
  try {
    await db.delete(schools).where(eq(schools.id, id));
  } catch (error) {
    console.error('Database deleteSchool failed:', error);
    throw new Error('Could not delete school from database.', { cause: error });
  }
}

// Students CRUD
export async function getStudents(): Promise<Student[]> {
  try {
    const list = await db.select().from(students);
    return list.map(s => ({
      id: s.id,
      name: s.name,
      grade: s.grade,
      section: s.section,
      gender: s.gender,
      schoolId: s.schoolId,
      schoolName: s.schoolName,
      parentMobile: s.parentMobile,
    }));
  } catch (error) {
    console.error('Database getStudents failed:', error);
    throw new Error('Could not fetch students from database.', { cause: error });
  }
}

export async function insertStudent(stu: Student): Promise<Student> {
  try {
    const result = await db.insert(students).values({
      id: stu.id,
      name: stu.name,
      grade: stu.grade,
      section: stu.section,
      gender: stu.gender,
      schoolId: stu.schoolId,
      schoolName: stu.schoolName,
      parentMobile: stu.parentMobile,
    }).returning();
    return result[0] as Student;
  } catch (error) {
    console.error('Database insertStudent failed:', error);
    throw new Error('Could not create student in database.', { cause: error });
  }
}

export async function updateStudent(id: string, stu: Partial<Student>): Promise<Student> {
  try {
    const result = await db.update(students)
      .set({
        name: stu.name,
        grade: stu.grade,
        section: stu.section,
        gender: stu.gender,
        schoolId: stu.schoolId,
        schoolName: stu.schoolName,
        parentMobile: stu.parentMobile,
      })
      .where(eq(students.id, id))
      .returning();
    return result[0] as Student;
  } catch (error) {
    console.error('Database updateStudent failed:', error);
    throw new Error('Could not update student in database.', { cause: error });
  }
}

export async function deleteStudent(id: string): Promise<void> {
  try {
    await db.delete(students).where(eq(students.id, id));
  } catch (error) {
    console.error('Database deleteStudent failed:', error);
    throw new Error('Could not delete student from database.', { cause: error });
  }
}

// Collection Entries CRUD
export async function getEntries(): Promise<CollectionEntry[]> {
  try {
    const list = await db.select().from(entries);
    return list.map(e => ({
      id: e.id,
      studentId: e.studentId,
      studentName: e.studentName,
      schoolId: e.schoolId,
      schoolName: e.schoolName,
      collectionDate: e.collectionDate,
      paperWeight: e.paperWeight,
      plasticWeight: e.plasticWeight,
      totalWeight: e.totalWeight,
      performance: e.performance as any,
    }));
  } catch (error) {
    console.error('Database getEntries failed:', error);
    throw new Error('Could not fetch entries from database.', { cause: error });
  }
}

export async function insertEntry(ent: CollectionEntry): Promise<CollectionEntry> {
  try {
    const result = await db.insert(entries).values({
      id: ent.id,
      studentId: ent.studentId,
      studentName: ent.studentName,
      schoolId: ent.schoolId,
      schoolName: ent.schoolName,
      collectionDate: ent.collectionDate,
      paperWeight: ent.paperWeight,
      plasticWeight: ent.plasticWeight,
      totalWeight: ent.totalWeight,
      performance: ent.performance,
    }).returning();
    return result[0] as CollectionEntry;
  } catch (error) {
    console.error('Database insertEntry failed:', error);
    throw new Error('Could not create collection entry in database.', { cause: error });
  }
}

export async function updateEntry(id: string, ent: Partial<CollectionEntry>): Promise<CollectionEntry> {
  try {
    const result = await db.update(entries)
      .set({
        studentId: ent.studentId,
        studentName: ent.studentName,
        schoolId: ent.schoolId,
        schoolName: ent.schoolName,
        collectionDate: ent.collectionDate,
        paperWeight: ent.paperWeight,
        plasticWeight: ent.plasticWeight,
        totalWeight: ent.totalWeight,
        performance: ent.performance,
      })
      .where(eq(entries.id, id))
      .returning();
    return result[0] as CollectionEntry;
  } catch (error) {
    console.error('Database updateEntry failed:', error);
    throw new Error('Could not update collection entry in database.', { cause: error });
  }
}

export async function deleteEntry(id: string): Promise<void> {
  try {
    await db.delete(entries).where(eq(entries.id, id));
  } catch (error) {
    console.error('Database deleteEntry failed:', error);
    throw new Error('Could not delete collection entry from database.', { cause: error });
  }
}

// Reset Database to mock state helper
export async function clearAndResetDb(): Promise<void> {
  try {
    await db.delete(entries);
    await db.delete(students);
    await db.delete(schools);

    // Re-seed
    for (const s of initialSchools) {
      await db.insert(schools).values({
        id: s.id,
        name: s.name,
        address: s.address,
        contactPerson: s.contactPerson,
        mobile: s.mobile,
        email: s.email,
        registrationDate: s.registrationDate,
      });
    }

    for (const s of initialStudents) {
      await db.insert(students).values({
        id: s.id,
        name: s.name,
        grade: s.grade,
        section: s.section,
        gender: s.gender,
        schoolId: s.schoolId,
        schoolName: s.schoolName,
        parentMobile: s.parentMobile,
      });
    }

    for (const e of initialEntries) {
      await db.insert(entries).values({
        id: e.id,
        studentId: e.studentId,
        studentName: e.studentName,
        schoolId: e.schoolId,
        schoolName: e.schoolName,
        collectionDate: e.collectionDate,
        paperWeight: e.paperWeight,
        plasticWeight: e.plasticWeight,
        totalWeight: e.totalWeight,
        performance: e.performance,
      });
    }
  } catch (error) {
    console.error('Database clearAndResetDb failed:', error);
    throw new Error('Could not reset and seed database.', { cause: error });
  }
}
