/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CollectionEntry, Student, School } from '../types';
import { Search, ArrowUpDown, Download, Printer, Filter, Check } from 'lucide-react';

interface DatabaseViewProps {
  entries: CollectionEntry[];
  students: Student[];
  schools: School[];
}

export default function DatabaseView({ entries, students, schools }: DatabaseViewProps) {
  // Filters and sorting states
  const [search, setSearch] = useState('');
  const [selectedSchool, setSelectedSchool] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('');
  const [sortDirection, setSortDirection] = useState<'desc' | 'asc'>('desc');

  // Find corresponding student record to obtain Grade/Standard info
  const enrichedEntries = entries.map((entry) => {
    const student = students.find((s) => s.id === entry.studentId);
    return {
      ...entry,
      studentId: student?.id || entry.studentId,
      grade: student?.grade || 'N/A',
    };
  });

  // Extract unique grades for filters
  const grades = Array.from(new Set(students.map((s) => s.grade))).filter(Boolean);

  // Filter and sort logic
  const filteredEntries = enrichedEntries.filter((entry) => {
    const matchesSearch =
      entry.studentName.toLowerCase().includes(search.toLowerCase()) ||
      entry.studentId.toLowerCase().includes(search.toLowerCase());
    const matchesSchool = !selectedSchool || entry.schoolId === selectedSchool;
    const matchesGrade = !selectedGrade || entry.grade === selectedGrade;
    return matchesSearch && matchesSchool && matchesGrade;
  });

  // Sorting by Total Weight
  const sortedEntries = [...filteredEntries].sort((a, b) => {
    return sortDirection === 'desc' 
      ? b.totalWeight - a.totalWeight 
      : a.totalWeight - b.totalWeight;
  });

  // Export to Excel (CSV)
  const handleExportCSV = () => {
    const headers = [
      'Student ID',
      'Student Name',
      'School ID',
      'School Name',
      'Grade/Standard',
      'Paper Weight (kg)',
      'Plastic Weight (kg)',
      'Total Weight (kg)',
      'Performance Rating',
      'Collection Date'
    ];

    const rows = sortedEntries.map((e) => [
      e.studentId,
      e.studentName,
      e.schoolId,
      e.schoolName,
      e.grade,
      e.paperWeight,
      e.plasticWeight,
      e.totalWeight,
      e.performance,
      e.collectionDate
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((r) => r.map((val) => `"${val}"`).join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'Waste_Recycling_Championship_Records.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export to PDF / Print Trigger
  const handlePrint = () => {
    // We isolate paper element and print using clean native print window
    window.print();
  };

  const getBadgeStyles = (perf: string) => {
    switch (perf) {
      case 'Excellent':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Best':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'Good':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      default:
        return 'bg-rose-100 text-rose-800 border-rose-300';
    }
  };

  return (
    <div id="database-view-wrapper" className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
        <div>
          <h2 id="db-view-title" className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
            Database Archive & Master Sheet
          </h2>
          <p className="text-slate-500 text-sm mt-0.5">
            Query, sort, search, and export the entire competition recycling ledger list.
          </p>
        </div>
        
        {/* Export Triggers */}
        <div className="flex gap-2">
          <button
            id="db-export-csv-btn"
            onClick={handleExportCSV}
            className="flex items-center gap-2 px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100/80 text-emerald-700 text-xs font-bold rounded-xl transition-all cursor-pointer border border-emerald-200"
          >
            <Download className="w-4 h-4" />
            Export to Excel
          </button>
          <button
            id="db-print-pdf-btn"
            onClick={handlePrint}
            className="flex items-center gap-2 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer border border-slate-200"
          >
            <Printer className="w-4 h-4" />
            Export to PDF / Print
          </button>
        </div>
      </div>

      {/* Control Filters panel */}
      <div id="db-filters-panel" className="bg-white border border-slate-100 p-5 rounded-3xl shadow-xs space-y-4 print:hidden">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
          <Filter className="w-4 h-4 text-emerald-600" />
          Filter & Query Records
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Text search */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Search Pupil</label>
            <div className="relative">
              <Search className="absolute left-3 top-2 text-slate-400 w-4 h-4" />
              <input
                id="db-search"
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search name or ID..."
                className="w-full pl-9 pr-3 py-1.5 border border-slate-200 text-xs rounded-xl focus:outline-none"
              />
            </div>
          </div>

          {/* School filter */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Filter School</label>
            <select
              id="db-school-select"
              value={selectedSchool}
              onChange={(e) => setSelectedSchool(e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-200 text-xs bg-slate-50 hover:bg-slate-100 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="">All Schools</option>
              {schools.map((sc) => (
                <option key={sc.id} value={sc.id}>
                  {sc.name}
                </option>
              ))}
            </select>
          </div>

          {/* Grade/Standard filter */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Filter Grade/Standard</label>
            <select
              id="db-grade-select"
              value={selectedGrade}
              onChange={(e) => setSelectedGrade(e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-200 text-xs bg-slate-50 hover:bg-slate-100 rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="">All Grades</option>
              {grades.map((gr) => (
                <option key={gr} value={gr}>
                  {gr}
                </option>
              ))}
            </select>
          </div>

          {/* Toggle sorting */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Sort by Weight</label>
            <button
              id="db-sort-weight-btn"
              onClick={() => setSortDirection(sortDirection === 'desc' ? 'asc' : 'desc')}
              className="w-full px-3 py-1.5 border border-slate-200 text-xs bg-emerald-50 text-emerald-800 hover:bg-emerald-100/80 rounded-xl flex items-center justify-center gap-1.5 font-bold cursor-pointer transition-all"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              Weight: {sortDirection === 'desc' ? 'High → Low (Desc)' : 'Low → High (Asc)'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Database Table Sheet */}
      <div id="db-main-sheet" className="bg-white border border-slate-100 rounded-3xl shadow-xs overflow-hidden print:border-0 print:shadow-none">
        
        {/* Printable/PDF Logo view only visible when printing */}
        <div className="hidden print:block p-6 border-b border-slate-300">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-emerald-800">Waste Recycling Championship</h1>
            <p className="text-sm text-slate-600 mt-1">Official Master Collection Ledger Database Reports</p>
            <p className="text-xs text-slate-400">Generated on {new Date().toLocaleDateString()} &middot; Status: Live Authenticated Record</p>
          </div>
        </div>

        {sortedEntries.length === 0 ? (
          <div id="db-empty-state" className="p-16 text-center text-slate-500">
            <p className="text-sm font-bold">No competition entries matched the configured queries.</p>
            <p className="text-xs text-slate-400 mt-1">Reset your filters or register more collection events.</p>
          </div>
        ) : (
          <div className="overflow-x-auto text-slate-700">
            <table id="db-ledger-table" className="w-full text-left border-collapse print:text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200/60 text-xs font-bold text-slate-505 uppercase tracking-widest print:bg-slate-100 text-slate-500">
                  <th className="py-3.5 px-6">ID & Date</th>
                  <th className="py-3.5 px-6">Pupil / ID</th>
                  <th className="py-3.5 px-6">School Details</th>
                  <th className="py-3.5 px-6">Grade</th>
                  <th className="py-3.5 px-6 text-right">Paper</th>
                  <th className="py-3.5 px-6 text-right">Plastic</th>
                  <th className="py-3.5 px-6 text-right text-emerald-800 font-bold">Total Weight</th>
                  <th className="py-3.5 px-6">Performance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {sortedEntries.map((item) => (
                  <tr key={item.id} id={`ledger-row-${item.id}`} className="hover:bg-slate-50/40 transition-colors">
                    <td className="py-4 px-6">
                      <div className="font-mono font-bold text-xs text-slate-500 leading-tight">{item.id}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{item.collectionDate}</div>
                    </td>
                    <td className="py-4 px-6 font-semibold text-slate-800">
                      <div>{item.studentName}</div>
                      <div className="text-[10px] text-slate-400 font-mono font-normal mt-0.5">{item.studentId}</div>
                    </td>
                    <td className="py-4 px-6 text-xs text-slate-500 font-semibold max-w-xs truncate">
                      {item.schoolName}
                    </td>
                    <td className="py-4 px-6">
                      <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[11px] font-bold">
                        {item.grade}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-right font-mono text-slate-600 text-xs">
                      {item.paperWeight.toFixed(1)} kg
                    </td>
                    <td className="py-4 px-6 text-right font-mono text-slate-600 text-xs">
                      {item.plasticWeight.toFixed(1)} kg
                    </td>
                    <td className="py-4 px-6 text-right font-mono text-emerald-800 font-bold">
                      {item.totalWeight.toFixed(1)} kg
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex px-2 px-2 py-0.5 rounded-full text-[11px] font-bold border ${getBadgeStyles(item.performance)}`}>
                        {item.performance}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
