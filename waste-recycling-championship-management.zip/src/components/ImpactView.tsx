/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CollectionEntry } from '../types';
import { Droplet, Globe, Sparkles, HelpCircle, Activity, Heart, ArrowUpRight } from 'lucide-react';

interface ImpactViewProps {
  entries: CollectionEntry[];
}

export default function ImpactView({ entries }: ImpactViewProps) {
  // 1 kg Paper Recycled = 17 Liters water saved
  // 1 kg Plastic Recycled = 6 kg CO2 emissions reduced
  const totalPaper = entries.reduce((sum, e) => sum + e.paperWeight, 0);
  const totalPlastic = entries.reduce((sum, e) => sum + e.plasticWeight, 0);
  const totalWeight = totalPaper + totalPlastic;

  const waterSaved = totalPaper * 17;
  const co2Reduced = totalPlastic * 6;

  // Real world equivalent metrics
  const treesSaved = (totalPaper * 0.017).toFixed(1); // 17 trees per ton (1000kg)
  const powerSaved = (totalWeight * 3.1).toFixed(0); // 3.1 kWh per kg saved
  const carMilesAvoided = (co2Reduced * 2.4).toFixed(0); // 2.4 miles per kg of CO2 equivalent emissions

  // Timeline daily points aggregation for the trend chart
  const dailyAggregation: { [key: string]: number } = {};
  entries.forEach((e) => {
    dailyAggregation[e.collectionDate] = (dailyAggregation[e.collectionDate] || 0) + e.totalWeight;
  });

  // Sort daily keys to construct chronological trend points
  const sortedDates = Object.keys(dailyAggregation).sort().slice(-7); // take last 7 active dates
  const trendPoints = sortedDates.map((d) => ({
    date: d.substring(5), // Keep MM-DD format
    weight: dailyAggregation[d]
  }));

  // SVG Chart Dimensions & responsive layout helpers
  const maxTrendWeight = trendPoints.length > 0 ? Math.max(...trendPoints.map((p) => p.weight), 10) : 50;

  // Doughnut chart mathematics
  const totalRatio = totalWeight > 0 ? totalWeight : 1;
  const paperPct = Math.round((totalPaper / totalRatio) * 100) || 50;
  const plasticPct = Math.round((totalPlastic / totalRatio) * 100) || 50;

  // Pie chart stroke calculations
  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  const paperStrokeDash = (paperPct / 100) * circumference;
  const plasticStrokeDash = circumference - paperStrokeDash;

  return (
    <div id="impact-view-wrapper" className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div>
        <h2 id="impact-view-title" className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
          Environmental Conservation Analytics
        </h2>
        <p className="text-slate-500 text-sm mt-0.5">
          Translating raw championship weights into authentic ecosystem preservation metrics.
        </p>
      </div>

      {/* Grid of Big Statistics Cards */}
      <div id="impact-grid" className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Paper Conversion Water Saved Card */}
        <div className="bg-emerald-600 rounded-3xl p-6 text-white shadow-xl shadow-emerald-600/10 relative overflow-hidden flex flex-col justify-between">
          <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 w-64 h-64 bg-emerald-500/20 rounded-full" />
          <div className="relative z-10">
            <div className="p-3 bg-white/10 w-fit rounded-2xl border border-white/10 flex items-center justify-center text-emerald-100">
              <Droplet className="w-8 h-8 text-cyan-200 animate-bounce" />
            </div>
            <h3 className="text-slate-100 font-semibold text-xs uppercase tracking-wider mt-5">Water Resources Conserved</h3>
            <p className="text-4xl font-black mt-2">{waterSaved.toLocaleString()} <span className="text-lg font-medium text-emerald-200">Liters</span></p>
            <p className="text-xs text-emerald-100/85 mt-2 leading-relaxed">
              Recycling paper prevents wastewater synthesis and minimizes standard industrial consumption loops.
            </p>
          </div>

          <div className="border-t border-white/10 mt-6 pt-4 flex justify-between items-center z-10 text-xs">
            <span className="text-emerald-100 font-medium">17L Preserved per 1kg Paper</span>
            <span className="px-2 py-0.5 bg-emerald-500/30 rounded-md font-mono">{totalPaper.toFixed(1)} kg paper logged</span>
          </div>
        </div>

        {/* Plastic Conversion CO2 Card */}
        <div className="bg-slate-900 rounded-3xl p-6 text-white border border-slate-800 shadow-xl relative overflow-hidden flex flex-col justify-between">
          <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 w-64 h-64 bg-emerald-500/5 rounded-full" />
          <div className="relative z-10">
            <div className="p-3 bg-white/5 w-fit rounded-2xl border border-white/10 flex items-center justify-center text-emerald-400">
              <Globe className="w-8 h-8 text-emerald-400" />
            </div>
            <h3 className="text-slate-400 font-semibold text-xs uppercase tracking-wider mt-5">Carbon Footprint Abated</h3>
            <p className="text-4xl font-black mt-2">{co2Reduced.toLocaleString()} <span className="text-lg font-medium text-slate-350">kg CO₂</span></p>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Diverting plastic scraps from landfills intercepts thermal degradation pathways and greenhouse outputs.
            </p>
          </div>

          <div className="border-t border-slate-800 mt-6 pt-4 flex justify-between items-center z-10 text-xs">
            <span className="text-slate-400 font-medium">6kg CO₂ Reduced per 1kg Plastic</span>
            <span className="px-2 py-0.5 bg-slate-800 rounded-md font-mono text-emerald-450">{totalPlastic.toFixed(1)} kg plastic logged</span>
          </div>
        </div>
      </div>

      {/* Equivalent Metrics Carousel panels */}
      <div id="impact-equivalents" className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-white border border-slate-100 p-5 rounded-3xl flex items-center gap-4 shadow-2xs">
          <div className="p-3 bg-emerald-50 text-emerald-700 rounded-2xl font-bold text-2xl flex-shrink-0">🌴</div>
          <div>
            <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">Trees Preserved</p>
            <h4 className="text-lg font-extrabold text-slate-850 mt-0.5">{treesSaved} mature trees</h4>
            <p className="text-[10px] text-slate-400">Equivalent paper saved</p>
          </div>
        </div>

        <div className="bg-white border border-slate-100 p-5 rounded-3xl flex items-center gap-4 shadow-2xs">
          <div className="p-3 bg-amber-50 text-amber-700 rounded-2xl font-bold text-2xl flex-shrink-0">⚡</div>
          <div>
            <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">Energy Retained</p>
            <h4 className="text-lg font-extrabold text-slate-850 mt-0.5">{powerSaved} Kilowatt-Hours</h4>
            <p className="text-[10px] text-slate-400">Standard appliance electrical load</p>
          </div>
        </div>

        <div className="bg-white border border-slate-100 p-5 rounded-3xl flex items-center gap-4 shadow-2xs">
          <div className="p-3 bg-sky-50 text-sky-700 rounded-2xl font-bold text-2xl flex-shrink-0">🚗</div>
          <div>
            <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">Auto Emissions Offset</p>
            <h4 className="text-lg font-extrabold text-slate-850 mt-0.5">{carMilesAvoided} Car-Miles Avoided</h4>
            <p className="text-[10px] text-slate-400">Regular petrol auto mileage offset</p>
          </div>
        </div>
      </div>

      {/* Beautiful High-Fidelity SVG Visual Charts section */}
      <div id="interactive-impact-charts" className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Doughnut distribution chart */}
        <div className="bg-white border border-slate-150 p-6 rounded-3xl shadow-xs">
          <div className="border-b border-slate-100 pb-3 mb-5 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-755 uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-emerald-600" />
              Recycling Distribution
            </h3>
            <span className="text-[11px] px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-md font-bold">Paper vs. Plastic</span>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-8 py-4">
            {/* SVG Doughnut */}
            <div className="relative w-40 h-40 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                {/* Background Ring */}
                <circle cx="60" cy="60" r={radius} fill="transparent" stroke="#f1f5f9" strokeWidth="12" />
                
                {/* Paper Segment */}
                <circle
                  cx="60"
                  cy="60"
                  r={radius}
                  fill="transparent"
                  stroke="#f59e0b" // Orange/Amber
                  strokeWidth="12"
                  strokeDasharray={`${paperStrokeDash} ${circumference}`}
                  className="transition-all duration-700"
                />

                {/* Plastic Segment */}
                <circle
                  cx="60"
                  cy="60"
                  r={radius}
                  fill="transparent"
                  stroke="#38bdf8" // Blue/Sky
                  strokeWidth="12"
                  strokeDasharray={`${plasticStrokeDash} ${circumference}`}
                  strokeDashoffset={-paperStrokeDash}
                  className="transition-all duration-700"
                />
              </svg>
              {/* Central Text HUD */}
              <div className="absolute text-center">
                <p className="text-xs font-semibold text-slate-400">Total Waste</p>
                <p className="text-lg font-black text-slate-800 mt-0.5">{totalWeight.toFixed(0)} <span className="text-xs">kg</span></p>
              </div>
            </div>

            {/* Chart Legend */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="w-3.5 h-3.5 bg-amber-500 rounded-md flex-shrink-0" />
                <div>
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">Paper Waste</p>
                  <p className="text-base font-extrabold text-slate-805 mt-0.5">{totalPaper.toFixed(1)} kg <span className="text-xs font-semibold text-amber-500">({paperPct}%)</span></p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <span className="w-3.5 h-3.5 bg-sky-400 rounded-md flex-shrink-0" />
                <div>
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">Plastic Waste</p>
                  <p className="text-base font-extrabold text-slate-805 mt-0.5">{totalPlastic.toFixed(1)} kg <span className="text-xs font-semibold text-sky-500">({plasticPct}%)</span></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Timeline chronological Curve line chart */}
        <div className="bg-white border border-slate-150 p-6 rounded-3xl shadow-xs">
          <div className="border-b border-slate-100 pb-3 mb-5 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-755 uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-emerald-600" />
              Recycling Progress Timeline
            </h3>
            <span className="text-[11px] px-2 py-0.5 bg-sky-50 text-sky-700 rounded-md font-bold">Chronological Trend</span>
          </div>

          {trendPoints.length === 0 ? (
            <div className="p-12 text-center text-slate-400">
              <p className="text-xs">Timeline requires some recorded collection logs to visualize progressive trend lines.</p>
            </div>
          ) : (
            <div className="py-2">
              {/* Responsive SVG Line Chart */}
              <svg className="w-full h-36" viewBox="0 0 400 150">
                {/* Visual Grid Lines */}
                <line x1="10" y1="20" x2="390" y2="20" stroke="#f1f5f9" strokeWidth="1" />
                <line x1="10" y1="70" x2="390" y2="70" stroke="#f1f5f9" strokeWidth="1" />
                <line x1="10" y1="120" x2="390" y2="120" stroke="#f8fafc" strokeWidth="1.5" />

                {/* Draw Trend Line Path */}
                {(() => {
                  const pointsCount = trendPoints.length;
                  const stepX = 380 / (pointsCount - 1 || 1);
                  const pathCoords = trendPoints.map((p, i) => {
                    const x = 10 + i * stepX;
                    const y = 120 - (p.weight / maxTrendWeight) * 100;
                    return `${x},${y}`;
                  });

                  return (
                    <>
                      {/* Gradient Area Fill Under Line */}
                      <path
                        d={`M 10,120 L ${pathCoords.map((coord) => coord).join(' L ')} L ${10 + (pointsCount - 1) * stepX},120 Z`}
                        fill="url(#trendGrad)"
                        opacity="0.15"
                      />

                      {/* Actual Stroke Line */}
                      <path
                        d={`M ${pathCoords.join(' L ')}`}
                        fill="transparent"
                        stroke="#10b981" // emerald-500
                        strokeWidth="3.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />

                      {/* Data point circles */}
                      {trendPoints.map((p, i) => {
                        const x = 10 + i * stepX;
                        const y = 120 - (p.weight / maxTrendWeight) * 100;
                        return (
                          <g key={i} className="group cursor-pointer">
                            <circle
                              cx={x}
                              cy={y}
                              r="5"
                              fill="#10b981"
                              stroke="#ffffff"
                              strokeWidth="2.5"
                              className="transition-all hover:r-7"
                            />
                            {/* Hover tooltip text */}
                            <text
                              x={x}
                              y={y - 12}
                              textAnchor="middle"
                              className="font-mono text-[9px] font-bold fill-slate-800"
                            >
                              {p.weight.toFixed(0)}kg
                            </text>
                          </g>
                        );
                      })}

                      {/* Date Labels below chart */}
                      {trendPoints.map((p, i) => {
                        const x = 10 + i * stepX;
                        return (
                          <text
                            key={i}
                            x={x}
                            y="140"
                            textAnchor="middle"
                            className="font-mono font-medium text-[8px] fill-slate-400"
                          >
                            {p.date}
                          </text>
                        );
                      })}

                      {/* SVG Gradient specifications */}
                      <defs>
                        <linearGradient id="trendGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#10b981" />
                          <stop offset="100%" stopColor="#ffffff" />
                        </linearGradient>
                      </defs>
                    </>
                  );
                })()}
              </svg>
              <p className="text-[10px] text-center text-slate-400 mt-3 font-mono">X: Collection Date (last 7 active) &bull; Y: Unified Deposits Weight (kg)</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
