/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Shield, Leaf, AlertCircle } from 'lucide-react';

interface LoginViewProps {
  onLoginSuccess: () => void;
}

export default function LoginView({ onLoginSuccess }: LoginViewProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'admin' && password === 'admin123') {
      localStorage.setItem('rc_admin_logged_in', 'true');
      onLoginSuccess();
    } else {
      setError('Invalid username or password. Try admin / admin123');
    }
  };

  const handleQuickLogin = () => {
    setUsername('admin');
    setPassword('admin123');
    setError('');
  };

  return (
    <div id="login-container" className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background design elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-emerald-100/40 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-green-100/40 rounded-full blur-3xl translate-x-1/3 translate-y-1/3" />

      <div className="sm:mx-auto sm:w-full sm:max-w-md z-10">
        <div className="flex justify-center items-center gap-3">
          <div id="login-logo-badge" className="p-3 bg-emerald-600 rounded-2xl text-white shadow-lg shadow-emerald-600/30">
            <Leaf className="w-8 h-8" />
          </div>
          <div>
            <h1 id="login-app-title" className="text-2xl font-bold text-slate-800 tracking-tight">Eco Championship</h1>
            <p className="text-xs font-semibold text-emerald-600 tracking-wider uppercase">Waste Recycling Management</p>
          </div>
        </div>
        <h2 id="login-subtitle" className="mt-8 text-center text-3xl font-extrabold text-slate-900 tracking-tight">
          Admin Portal
        </h2>
        <p className="mt-2 text-center text-sm text-slate-500">
          Interschool Waste Recycling Championship System
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md z-10">
        <div id="login-card" className="bg-white py-8 px-4 shadow-xl border border-slate-100 sm:rounded-2xl sm:px-10">
          <form className="space-y-6" onSubmit={handleLogin}>
            {error && (
              <div id="login-error-message" className="p-3 bg-rose-50 border-l-4 border-rose-500 text-rose-700 text-sm flex items-center gap-2 rounded-r-md">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div>
              <label htmlFor="username" className="block text-sm font-medium text-slate-700">
                Username
              </label>
              <div className="mt-1">
                <input
                  id="username"
                  name="username"
                  type="text"
                  required
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="appearance-none block w-full px-3 py-2 border border-slate-300 rounded-lg shadow-sm placeholder-slate-400 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm transition-colors"
                  placeholder="Enter admin"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-slate-700">
                Password
              </label>
              <div className="mt-1">
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="appearance-none block w-full px-3 py-2 border border-slate-300 rounded-lg shadow-sm placeholder-slate-400 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm transition-colors"
                  placeholder="Enter admin123"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <button
                id="quick-credentials-btn"
                type="button"
                onClick={handleQuickLogin}
                className="text-xs text-emerald-600 hover:text-emerald-500 font-medium flex items-center gap-1 transition-colors"
              >
                <Shield className="w-3.5 h-3.5" />
                Autofill Credentials
              </button>
            </div>

            <div>
              <button
                id="login-submit-btn"
                type="submit"
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-lg shadow-md hover:shadow-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-all cursor-pointer"
              >
                Sign In to System
              </button>
            </div>
          </form>

          <div className="mt-6 border-t border-slate-100 pt-6">
            <div className="rounded-lg bg-emerald-50/50 p-4 border border-emerald-100">
              <h4 className="text-xs font-semibold text-emerald-800 uppercase tracking-wide">System Requirements & Access</h4>
              <p className="mt-1 text-xs text-emerald-700 leading-relaxed">
                Use the default credentials to access the complete admin panel. You can manage Schools, Students, Recyclable Collection Logs, and download CSV performance sheets.
              </p>
              <div className="mt-2 flex gap-4 text-xs font-mono text-slate-600">
                <span>User: <strong className="text-emerald-800">admin</strong></span>
                <span>Pass: <strong className="text-emerald-800">admin123</strong></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
