/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CollectionEntry, Student, School } from '../types';
import { FileBarChart, Download, Printer, ArrowRight, Table, HelpCircle } from 'lucide-react';

interface ReportsViewProps {
  entries: CollectionEntry[];
  students: Student[];
  schools: School[];
}

type ReportType = 'school' | 'student' | 'daily' | 'monthly';

export default function ReportsView({ entries, students, schools }: ReportsViewProps) {
  const [reportType, setReportType] = useState<ReportType>('school');

  // --- 1. School Wise Report compilation ---
  const compileSchoolWise = () => {
    return schools.map((sc) => {
      const schoolEntries = entries.filter((e) => e.schoolId === sc.id);
      const schoolStudents = students.filter((s) => s.schoolId === sc.id);
      const paperTotal = schoolEntries.reduce((sum, e) => sum + e.paperWeight, 0);
      const plasticTotal = schoolEntries.reduce((sum, e) => sum + e.plasticWeight, 0);
      const totalWeight = paperTotal + plasticTotal;

      return {
        id: sc.id,
        name: sc.name,
        studentCount: schoolStudents.length,
        entryCount: schoolEntries.length,
        paperTotal,
        plasticTotal,
        totalWeight,
        averageDeposit: schoolEntries.length > 0 ? totalWeight / schoolEntries.length : 0,
      };
    });
  };

  // --- 2. Student Wise Report compilation ---
  const compileStudentWise = () => {
    return students.map((st) => {
      const studentEntries = entries.filter((e) => e.studentId === st.id);
      const paperTotal = studentEntries.reduce((sum, e) => sum + e.paperWeight, 0);
      const plasticTotal = studentEntries.reduce((sum, e) => sum + e.plasticWeight, 0);
      const totalWeight = paperTotal + plasticTotal;

      // Calculate performance breakdown counted
      let excellentLimit = 0;
      let worstLimit = 0;
      studentEntries.forEach((e) => {
        if (e.performance === 'Excellent') excellentLimit++;
        if (e.performance === 'Needs Improvement') worstLimit++;
      });

      return {
        id: st.id,
        name: st.name,
        schoolName: st.schoolName,
        grade: st.grade,
        entryCount: studentEntries.length,
        paperTotal,
        plasticTotal,
        totalWeight,
        excellentCount: excellentLimit,
        needsImprovementCount: worstLimit,
      };
    });
  };

  // --- 3. Daily Collection Report compilation ---
  const compileDailyWise = () => {
    const dailyMap: { [key: string]: { paper: number; plastic: number; total: number; entriesCount: number } } = {};
    entries.forEach((e) => {
      const d = e.collectionDate;
      if (!dailyMap[d]) {
        dailyMap[d] = { paper: 0, plastic: 0, total: 0, entriesCount: 0 };
      }
      dailyMap[d].paper += e.paperWeight;
      dailyMap[d].plastic += e.plasticWeight;
      dailyMap[d].total += e.totalWeight;
      dailyMap[d].entriesCount += 1;
    });

    // Sort by date descending
    return Object.entries(dailyMap)
      .map(([date, data]) => ({
        date,
        ...data,
      }))
      .sort((a, b) => b.date.localeCompare(a.date));
  };

  // --- 4. Monthly Collection Report compilation ---
  const compileMonthlyWise = () => {
    const monthlyMap: { [key: string]: { paper: number; plastic: number; total: number; entriesCount: number } } = {};
    
    entries.forEach((e) => {
      // Date format is YYYY-MM-DD, slice indices [0, 7] gets YYYY-MM
      const m = e.collectionDate.substring(0, 7);
      if (!monthlyMap[m]) {
        monthlyMap[m] = { paper: 0, plastic: 0, total: 0, entriesCount: 0 };
      }
      monthlyMap[m].paper += e.paperWeight;
      monthlyMap[m].plastic += e.plasticWeight;
      monthlyMap[m].total += e.totalWeight;
      monthlyMap[m].entriesCount += 1;
    });

    // Translate format YYYY-MM to human Month Year e.g. "June 2026"
    const getMonthName = (yrMo: string) => {
      const [yr, mo] = yrMo.split('-');
      const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      const index = parseInt(mo) - 1;
      return index >= 0 && index < 12 ? `${months[index]} ${yr}` : yrMo;
    };

    return Object.entries(monthlyMap)
      .map(([monthCode, data]) => ({
        monthCode,
        monthName: getMonthName(monthCode),
        ...data,
      }))
      .sort((a, b) => b.monthCode.localeCompare(a.monthCode));
  };

  // Trigger export reports download to excel logic
  const handleExportCSVReport = () => {
    let headers: string[] = [];
    let rows: any[][] = [];
    let filename = '';

    if (reportType === 'school') {
      filename = 'School_Recycling_Performance_Report';
      headers = ['School ID', 'School Name', 'Registered Students', 'Collection Deposits logged', 'Paper Collected (kg)', 'Plastic Collected (kg)', 'Total Collected (kg)', 'Average Deposit (kg)'];
      rows = compileSchoolWise().map((r) => [r.id, r.name, r.studentCount, r.entryCount, r.paperTotal.toFixed(1), r.plasticTotal.toFixed(1), r.totalWeight.toFixed(1), r.averageDeposit.toFixed(1)]);
    } else if (reportType === 'student') {
      filename = 'Student_Recycling_Performance_Report';
      headers = ['Student ID', 'Student Name', 'School Name', 'Grade', 'Deposits Logged', 'Paper Weight (kg)', 'Plastic Weight (kg)', 'Total Weight (kg)', 'Excellent Awards Earned', 'Needs Improvement Logs'];
      rows = compileStudentWise().map((st) => [st.id, st.name, st.schoolName, st.grade, st.entryCount, st.paperTotal.toFixed(1), st.plasticTotal.toFixed(1), st.totalWeight.toFixed(1), st.excellentCount, st.needsImprovementCount]);
    } else if (reportType === 'daily') {
      filename = 'Daily_Recycling_Collection_Report';
      headers = ['Date', 'Entries Logged', 'Daily Paper Weight (kg)', 'Daily Plastic Weight (kg)', 'Total Combined Daily (kg)'];
      rows = compileDailyWise().map((d) => [d.date, d.entriesCount, d.paper.toFixed(1), d.plastic.toFixed(1), d.total.toFixed(1)]);
    } else if (reportType === 'monthly') {
      filename = 'Monthly_Recycling_Collection_Report';
      headers = ['Month Period', 'Deposits Counted', 'Monthly Paper Total (kg)', 'Monthly Plastic Total (kg)', 'Monthly Combined Total (kg)'];
      rows = compileMonthlyWise().map((m) => [m.monthCode, m.entriesCount, m.paper.toFixed(1), m.plastic.toFixed(1), m.total.toFixed(1)]);
    }

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((r) => r.map((val) => `"${val}"`).join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const currentSchoolData = compileSchoolWise();
  const currentStudentData = compileStudentWise();
  const currentDailyData = compileDailyWise();
  const currentMonthlyData = compileMonthlyWise();

  return (
    <div id="reports-view-wrapper" className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
        <div>
          <h2 id="reports-view-title" className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
            <FileBarChart className="w-7 h-7 text-emerald-600" />
            Competitive Reports & Analytics
          </h2>
          <p className="text-slate-500 text-sm mt-0.5">
            Compile breakdown tables, daily collections, student rankings, and environmental progression trends.
          </p>
        </div>

        <div className="flex gap-2">
          <button
            id="reports-excel-btn"
            onClick={handleExportCSVReport}
            className="flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl transition-all cursor-pointer shadow-md shadow-emerald-600/10"
          >
            <Download className="w-4 h-4" />
            Export Selected Report
          </button>
          <button
            id="reports-print-btn"
            onClick={() => window.print()}
            className="flex items-center gap-2 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-705 text-xs font-semibold rounded-xl transition-all cursor-pointer border border-slate-200"
          >
            <Printer className="w-4 h-4" />
            Print Report Sheet
          </button>
        </div>
      </div>

      {/* Report Context tab toggles */}
      <div id="reports-sub-tabs" className="grid grid-cols-2 md:grid-cols-4 gap-3 print:hidden">
        <button
          id="report-tab-school"
          onClick={() => setReportType('school')}
          className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
            reportType === 'school'
              ? 'border-emerald-500 bg-emerald-50 bg-opacity-70 text-emerald-900 ring-1 ring-emerald-500/20'
              : 'border-slate-100 bg-white text-slate-650 hover:bg-slate-50/60'
          }`}
        >
          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Context I</p>
          <h4 className="text-sm font-bold mt-1">School-Wise Report</h4>
          <p className="text-[11px] text-slate-400 mt-2">Check cumulative weights & averages representing schools.</p>
        </button>

        <button
          id="report-tab-student"
          onClick={() => setReportType('student')}
          className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
            reportType === 'student'
              ? 'border-emerald-500 bg-emerald-50 bg-opacity-70 text-emerald-900 ring-1 ring-emerald-500/20'
              : 'border-slate-100 bg-white text-slate-650 hover:bg-slate-50/60'
          }`}
        >
          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Context II</p>
          <h4 className="text-sm font-bold mt-1">Student-Wise Report</h4>
          <p className="text-[11px] text-slate-400 mt-2">Breakdown records per registered student participant.</p>
        </button>

        <button
          id="report-tab-daily"
          onClick={() => setReportType('daily')}
          className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
            reportType === 'daily'
              ? 'border-emerald-500 bg-emerald-50 bg-opacity-70 text-emerald-900 ring-1 ring-emerald-500/20'
              : 'border-slate-100 bg-white text-slate-650 hover:bg-slate-50/60'
          }`}
        >
          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Context III</p>
          <h4 className="text-sm font-bold mt-1">Daily Records Chart</h4>
          <p className="text-[11px] text-slate-400 mt-2">Analyze timeline list sorted by daily collection date.</p>
        </button>

        <button
          id="report-tab-monthly"
          onClick={() => setReportType('monthly')}
          className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
            reportType === 'monthly'
              ? 'border-emerald-500 bg-emerald-50 bg-opacity-70 text-emerald-900 ring-1 ring-emerald-500/20'
              : 'border-slate-100 bg-white text-slate-650 hover:bg-slate-50/60'
          }`}
        >
          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Context IV</p>
          <h4 className="text-sm font-bold mt-1">Monthly Analytics</h4>
          <p className="text-[11px] text-slate-400 mt-2">Evaluate monthly trends and active engagement logs.</p>
        </button>
      </div>

      {/* Main compilation table board */}
      <div id="reports-output-table" className="bg-white border border-slate-150 rounded-3xl shadow-xs overflow-hidden print:border-0 print:shadow-none">
        {/* Printable brand banner */}
        <div className="hidden print:block text-center p-6 border-b border-slate-350">
          <h2 className="text-xl font-bold text-emerald-800 uppercase tracking-wider">ECO RECYCLING CHAMPIONSHIP REPORT</h2>
          <p className="text-xs text-slate-500 mt-1 uppercase tracking-widest">
            {reportType === 'school' && 'Participating School Wise Cumulative report'}
            {reportType === 'student' && 'Full Student-Wise Recycled Performance Audit'}
            {reportType === 'daily' && 'Daily Progressive Raw Waste Collections Ledger'}
            {reportType === 'monthly' && 'Monthly Analytical Aggregation Chart'}
          </p>
          <p className="text-[10px] text-slate-400 mt-0.5">Printed at {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()} by System Administrator.</p>
        </div>

        {/* --- Render SCHOOL wise report --- */}
        {reportType === 'school' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left col-collapse" id="report-school-wise">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-widest">
                  <th className="py-3.5 px-6">School ID</th>
                  <th className="py-3.5 px-6">School Name</th>
                  <th className="py-3.5 px-6 text-center">Active Pupils</th>
                  <th className="py-3.5 px-6 text-center">Deposits Logged</th>
                  <th className="py-3.5 px-6 text-right">Paper Collected</th>
                  <th className="py-3.5 px-6 text-right">Plastic Collected</th>
                  <th className="py-3.5 px-6 text-right text-emerald-800 font-bold">Total Weight (Sum)</th>
                  <th className="py-3.5 px-6 text-right">Avg / Deposit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {currentSchoolData.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-50/30 transition-colors">
                    <td className="py-4 px-6 font-mono font-bold text-xs text-emerald-800">{row.id}</td>
                    <td className="py-4 px-6 font-bold text-slate-800">{row.name}</td>
                    <td className="py-4 px-6 text-center text-slate-600 font-semibold">{row.studentCount} students</td>
                    <td className="py-4 px-6 text-center text-slate-550 font-medium">{row.entryCount} times</td>
                    <td className="py-4 px-6 text-right font-mono text-xs text-slate-500">{row.paperTotal.toFixed(1)} kg</td>
                    <td className="py-4 px-6 text-right font-mono text-xs text-slate-500">{row.plasticTotal.toFixed(1)} kg</td>
                    <td className="py-4 px-6 text-right font-mono font-black text-emerald-800 text-sm">{row.totalWeight.toFixed(1)} kg</td>
                    <td className="py-4 px-6 text-right font-mono text-xs text-slate-400 font-medium">{row.averageDeposit.toFixed(1)} kg</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* --- Render STUDENT wise report --- */}
        {reportType === 'student' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left col-collapse" id="report-student-wise">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-505 uppercase tracking-widest">
                  <th className="py-3.5 px-6">ID & Rep</th>
                  <th className="py-3.5 px-6">Affiliated School</th>
                  <th className="py-3.5 px-6">Grade</th>
                  <th className="py-3.5 px-6 text-center">Deposits Logged</th>
                  <th className="py-3.5 px-6 text-right">Paper Collected</th>
                  <th className="py-3.5 px-6 text-right">Plastic Collected</th>
                  <th className="py-3.5 px-6 text-right text-indigo-800 font-bold">Total Weight (Sum)</th>
                  <th className="py-3.5 px-6 text-center text-emerald-600">Excellent Awards</th>
                  <th className="py-3.5 px-6 text-center text-rose-600">Needs Imp.</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {currentStudentData.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-50/30 transition-colors">
                    <td className="py-4 px-6 leading-tight">
                      <div className="font-bold text-slate-800">{row.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">{row.id}</div>
                    </td>
                    <td className="py-4 px-6 text-xs text-slate-500 font-semibold max-w-[200px] truncate">{row.schoolName}</td>
                    <td className="py-4 px-6">
                      <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[11px] font-bold">{row.grade}</span>
                    </td>
                    <td className="py-4 px-6 text-center text-slate-600 font-semibold">{row.entryCount} logs</td>
                    <td className="py-4 px-6 text-right font-mono text-xs text-slate-500">{row.paperTotal.toFixed(1)} kg</td>
                    <td className="py-4 px-6 text-right font-mono text-xs text-slate-500">{row.plasticTotal.toFixed(1)} kg</td>
                    <td className="py-4 px-6 text-right font-mono font-bold text-indigo-700">{row.totalWeight.toFixed(1)} kg</td>
                    <td className="py-4 px-6 text-center">
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-850 rounded-full text-xs font-extrabold">{row.excellentCount} times</span>
                    </td>
                    <td className="py-4 px-6 text-center">
                      <span className="px-2 py-0.5 bg-rose-100 text-rose-800 rounded-full text-xs font-extrabold">{row.needsImprovementCount} times</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* --- Render DAILY collections report --- */}
        {reportType === 'daily' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left col-collapse" id="report-daily-wise">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-widest">
                  <th className="py-3.5 px-6">Date</th>
                  <th className="py-3.5 px-6">Depositing Entries Combined</th>
                  <th className="py-3.5 px-6 text-right">Daily Sum Paper (kg)</th>
                  <th className="py-3.5 px-6 text-right">Daily Sum Plastic (kg)</th>
                  <th className="py-3.5 px-6 text-right text-emerald-800 font-bold">Total Daily Collective (kg)</th>
                  <th className="py-3.5 px-6">Contribution Share</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {currentDailyData.map((row) => {
                  const share = row.total > 0 ? (row.paper / row.total) * 105 : 0;
                  return (
                    <tr key={row.date} className="hover:bg-slate-50/30 transition-colors">
                      <td className="py-4 px-6 font-mono font-bold text-slate-800">{row.date}</td>
                      <td className="py-4 px-6 font-semibold text-slate-655">{row.entriesCount} collections</td>
                      <td className="py-4 px-6 text-right font-mono text-slate-600 text-xs">{row.paper.toFixed(1)} kg</td>
                      <td className="py-4 px-6 text-right font-mono text-slate-600 text-xs">{row.plastic.toFixed(1)} kg</td>
                      <td className="py-4 px-6 text-right font-mono font-extrabold text-emerald-700">{row.total.toFixed(1)} kg</td>
                      <td className="py-4 px-6 font-medium text-xs text-slate-400">
                        <span className="text-amber-500 font-bold">{Math.round((row.paper / row.total) * 100) || 0}% paper</span> &middot;{' '}
                        <span className="text-sky-500 font-bold">{Math.round((row.plastic / row.total) * 100) || 0}% plastic</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* --- Render MONTHLY collection report --- */}
        {reportType === 'monthly' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left col-collapse" id="report-monthly-wise">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-widest">
                  <th className="py-3.5 px-6">Month Code</th>
                  <th className="py-3.5 px-6">Month Name</th>
                  <th className="py-3.5 px-6">Accumulated Collections count</th>
                  <th className="py-3.5 px-6 text-right">Paper Collected Weight (kg)</th>
                  <th className="py-3.5 px-6 text-right">Plastic Collected Weight (kg)</th>
                  <th className="py-3.5 px-6 text-right text-emerald-800 font-bold">Total Monthly Collective Weight (kg)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {currentMonthlyData.map((row) => (
                  <tr key={row.monthCode} className="hover:bg-slate-50/30 transition-colors">
                    <td className="py-4 px-6 font-mono text-emerald-800 font-bold text-xs">{row.monthCode}</td>
                    <td className="py-4 px-6 font-extrabold text-slate-800">{row.monthName}</td>
                    <td className="py-4 px-6 font-semibold text-slate-600">{row.entriesCount} deposits logged</td>
                    <td className="py-4 px-6 text-right font-mono text-slate-500 text-xs">{row.paper.toFixed(1)} kg</td>
                    <td className="py-4 px-6 text-right font-mono text-slate-500 text-xs">{row.plastic.toFixed(1)} kg</td>
                    <td className="py-4 px-6 text-right font-mono font-black text-emerald-800 text-base">{row.total.toFixed(1)} kg</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
