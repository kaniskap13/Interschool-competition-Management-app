/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { School } from '../types';
import { School as SchoolIcon, Edit2, Trash2, Mail, Phone, MapPin, User, Calendar, Plus, Search, CheckCircle, AlertTriangle } from 'lucide-react';

interface SchoolsViewProps {
  schools: School[];
  onAddSchool: (school: School) => void;
  onEditSchool: (school: School) => void;
  onDeleteSchool: (id: string) => void;
}

export default function SchoolsView({ schools, onAddSchool, onEditSchool, onDeleteSchool }: SchoolsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingSchool, setEditingSchool] = useState<School | null>(null);

  // Form States
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [registrationDate, setRegistrationDate] = useState(new Date().toISOString().substring(0, 10));

  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const triggerNotification = (message: string, type: 'success' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  const handleOpenAdd = () => {
    setEditingSchool(null);
    setName('');
    setAddress('');
    setContactPerson('');
    setMobile('');
    setEmail('');
    setRegistrationDate(new Date().toISOString().substring(0, 10));
    setIsFormOpen(true);
  };

  const handleOpenEdit = (school: School) => {
    setEditingSchool(school);
    setName(school.name);
    setAddress(school.address);
    setContactPerson(school.contactPerson);
    setMobile(school.mobile);
    setEmail(school.email);
    setRegistrationDate(school.registrationDate);
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim() || !contactPerson.trim() || !mobile.trim() || !email.trim()) {
      triggerNotification('Please fill in all mandatory fields', 'error');
      return;
    }

    if (editingSchool) {
      // Editing
      const updatedSchool: School = {
        ...editingSchool,
        name,
        address,
        contactPerson,
        mobile,
        email,
        registrationDate,
      };
      onEditSchool(updatedSchool);
      triggerNotification(`${name} updated successfully!`);
    } else {
      // Create auto generated ID e.g. SCH-005
      // find next maximum id counter
      let nextIdNum = 1;
      if (schools.length > 0) {
        const ids = schools
          .map((s) => parseInt(s.id.replace('SCH-', '')))
          .filter((n) => !isNaN(n));
        if (ids.length > 0) {
          nextIdNum = Math.max(...ids) + 1;
        }
      }
      const newId = `SCH-${nextIdNum.toString().padStart(3, '0')}`;

      const newSchool: School = {
        id: newId,
        name,
        address,
        contactPerson,
        mobile,
        email,
        registrationDate,
      };
      onAddSchool(newSchool);
      triggerNotification(`${name} added with ID ${newId}`);
    }

    setIsFormOpen(false);
  };

  const handleDelete = (id: string, schoolName: string) => {
    onDeleteSchool(id);
  };

  const filteredSchools = schools.filter((s) =>
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.contactPerson.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div id="schools-view-wrapper" className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 id="schools-view-title" className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
            <SchoolIcon className="w-7 h-7 text-emerald-600" />
            School Registration
          </h2>
          <p className="text-slate-500 text-sm mt-0.5">
            Register and manage school directories participating in the competition.
          </p>
        </div>
        <button
          id="toggle-register-form-btn"
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-emerald-600/10 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Register New School
        </button>
      </div>

      {notification && (
        <div
          id="schools-toast"
          className={`p-4 rounded-xl border flex items-center gap-3 animate-slideIn ${
            notification.type === 'success'
              ? 'bg-emerald-50 border-emerald-100 text-emerald-800'
              : 'bg-rose-50 border-rose-100 text-rose-800'
          }`}
        >
          {notification.type === 'success' ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
          <span className="text-sm font-medium">{notification.message}</span>
        </div>
      )}

      {/* Registration/Edit Form Panel Modal overlay */}
      {isFormOpen && (
        <div id="form-modal-overlay" className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div id="form-modal-card" className="bg-white rounded-3xl shadow-xl border border-slate-100 w-full max-w-xl overflow-hidden animate-zoomIn">
            <div className="bg-emerald-600 text-white px-6 py-4 flex items-center justify-between">
              <h3 id="form-modal-header" className="text-lg font-bold">
                {editingSchool ? `Edit School: ${editingSchool.id}` : 'Register New Participating School'}
              </h3>
              <button
                id="form-modal-close"
                onClick={() => setIsFormOpen(false)}
                className="text-emerald-100 hover:text-white text-sm font-semibold cursor-pointer"
              >
                Cancel
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label htmlFor="school-form-name" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">School Name *</label>
                  <div className="relative">
                    <SchoolIcon className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      id="school-form-name"
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Greenwood Academy"
                      className="w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label htmlFor="school-form-address" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">School Address</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      id="school-form-address"
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="Full Address"
                      className="w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="school-form-contact" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Contact Person *</label>
                  <div className="relative">
                    <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      id="school-form-contact"
                      type="text"
                      required
                      value={contactPerson}
                      onChange={(e) => setContactPerson(e.target.value)}
                      placeholder="Principal / Coordinator Name"
                      className="w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="school-form-mobile" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Mobile Number *</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      id="school-form-mobile"
                      type="tel"
                      required
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value)}
                      placeholder="Line/Mobile"
                      className="w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="school-form-email" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Email Address *</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      id="school-form-email"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="contact@schoolmail.org"
                      className="w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="school-form-date" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Registration Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      id="school-form-date"
                      type="date"
                      value={registrationDate}
                      onChange={(e) => setRegistrationDate(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>

              <div id="school-form-footer" className="mt-6 flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  id="school-cancel-btn"
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-750 text-sm font-semibold rounded-lg hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  id="school-save-btn"
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-lg cursor-pointer shadow-xs"
                >
                  {editingSchool ? 'Apply Changes' : 'Register School'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Database Search & List panel */}
      <div id="school-table-card" className="bg-white border border-slate-100 rounded-2xl shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              id="school-search-box"
              type="text"
              placeholder="Search by school, contact, ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 border border-slate-200 text-sm rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
          <span className="text-xs text-slate-500 font-medium">
            Showing {filteredSchools.length} of {schools.length} registered schools
          </span>
        </div>

        {filteredSchools.length === 0 ? (
          <div id="schools-empty-state" className="p-12 text-center text-slate-500">
            <SchoolIcon className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-sm font-medium">No schools found matching search criteria.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table id="schools-table" className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200/60 text-xs font-bold text-slate-500 uppercase tracking-widest">
                  <th className="py-3.5 px-6">School ID</th>
                  <th className="py-3.5 px-6">School Details</th>
                  <th className="py-3.5 px-6">Contact Person</th>
                  <th className="py-3.5 px-6">Contact Info</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100/80 text-sm">
                {filteredSchools.map((school) => (
                  <tr key={school.id} id={`school-row-${school.id}`} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-4 px-6 font-mono font-semibold text-emerald-700 text-xs shrink-0">
                      {school.id}
                    </td>
                    <td className="py-4 px-6">
                      <div className="font-bold text-slate-850 text-sm">{school.name}</div>
                      {school.address && (
                        <div className="text-slate-400 text-xs flex items-center gap-1 mt-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          <span className="truncate max-w-sm">{school.address}</span>
                        </div>
                      )}
                    </td>
                    <td className="py-4 px-6 text-slate-700 font-medium">
                      <div className="flex items-center gap-2">
                        <span className="w-7 h-7 bg-emerald-500/10 text-emerald-700 rounded-full flex items-center justify-center text-xs font-black">
                          {school.contactPerson.substring(0, 1).toUpperCase()}
                        </span>
                        {school.contactPerson}
                      </div>
                    </td>
                    <td className="py-4 px-6 space-y-1">
                      <div className="text-slate-600 text-xs flex items-center gap-1.5 font-medium">
                        <Phone className="w-3.5 h-3.5 text-slate-400" /> {school.mobile}
                      </div>
                      <div className="text-slate-500 text-xs flex items-center gap-1.5 lowercase">
                        <Mail className="w-3.5 h-3.5 text-slate-400" /> {school.email}
                      </div>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <div className="inline-flex gap-1.5">
                        <button
                          id={`school-edit-${school.id}`}
                          onClick={() => handleOpenEdit(school)}
                          title="Edit Directory"
                          className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-all cursor-pointer"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          id={`school-delete-${school.id}`}
                          onClick={() => handleDelete(school.id, school.name)}
                          title="Delete Directory"
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
