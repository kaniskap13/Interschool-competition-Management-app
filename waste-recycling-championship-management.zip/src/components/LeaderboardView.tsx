/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CollectionEntry, Student, School } from '../types';
import { Trophy, Award, School as SchoolIcon, Users, Flame, Star } from 'lucide-react';

interface LeaderboardViewProps {
  entries: CollectionEntry[];
  students: Student[];
  schools: School[];
}

export default function LeaderboardView({ entries, students, schools }: LeaderboardViewProps) {
  const [activeTab, setActiveTab] = useState<'students' | 'schools'>('students');

  // --- Student Leaderboard Logic ---
  // Aggregate waste collected per student
  const studentTotalsMap: {
    [key: string]: {
      id: string;
      name: string;
      schoolName: string;
      paperTotal: number;
      plasticTotal: number;
      totalWeight: number;
    };
  } = {};

  entries.forEach((e) => {
    if (!studentTotalsMap[e.studentId]) {
      studentTotalsMap[e.studentId] = {
        id: e.studentId,
        name: e.studentName,
        schoolName: e.schoolName,
        paperTotal: 0,
        plasticTotal: 0,
        totalWeight: 0,
      };
    }
    const target = studentTotalsMap[e.studentId];
    target.paperTotal += e.paperWeight;
    target.plasticTotal += e.plasticWeight;
    target.totalWeight += e.totalWeight;
  });

  // Convert to sorted array
  const studentRankings = Object.values(studentTotalsMap).sort((a, b) => b.totalWeight - a.totalWeight);

  // --- School Leaderboard Logic ---
  // Aggregate waste collected per school
  const schoolTotalsMap: {
    [key: string]: {
      id: string;
      name: string;
      paperTotal: number;
      plasticTotal: number;
      totalWeight: number;
      studentCount: number;
    };
  } = {};

  // Preset all registered schools so even schools with 0 logs are accounted for
  schools.forEach((s) => {
    schoolTotalsMap[s.id] = {
      id: s.id,
      name: s.name,
      paperTotal: 0,
      plasticTotal: 0,
      totalWeight: 0,
      studentCount: 0,
    };
  });

  // Calculate student count per school
  students.forEach((stud) => {
    if (schoolTotalsMap[stud.schoolId]) {
      schoolTotalsMap[stud.schoolId].studentCount += 1;
    }
  });

  // Aggregate weights
  entries.forEach((e) => {
    if (schoolTotalsMap[e.schoolId]) {
      const target = schoolTotalsMap[e.schoolId];
      target.paperTotal += e.paperWeight;
      target.plasticTotal += e.plasticWeight;
      target.totalWeight += e.totalWeight;
    }
  });

  // Convert to sorted array
  const schoolRankings = Object.values(schoolTotalsMap).sort((a, b) => b.totalWeight - a.totalWeight);

  // Styling helper for rank badge
  const getRankBadge = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-amber-100 text-amber-800 border-amber-300 ring-2 ring-amber-400';
      case 2:
        return 'bg-slate-205 bg-slate-100 text-slate-800 border-slate-300 ring-2 ring-slate-300';
      case 3:
        return 'bg-orange-100 text-orange-850 border-orange-300 ring-2 ring-orange-300';
      default:
        return 'bg-slate-50 text-slate-500 border-slate-200';
    }
  };

  const getRankIndicatorEmoji = (rank: number) => {
    switch (rank) {
      case 1:
        return '🥇';
      case 2:
        return '🥈';
      case 3:
        return '🥉';
      default:
        return `#${rank}`;
    }
  };

  return (
    <div id="leaderboard-view-wrapper" className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div>
        <h2 id="leaderboard-view-title" className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
          <Trophy className="w-7 h-7 text-amber-500" />
          Championship Leaderboards
        </h2>
        <p className="text-slate-500 text-sm mt-0.5">
          Celebrating eco-champion schools and top recycling students on their cumulative waste performance.
        </p>
      </div>

      {/* Tab Switcher */}
      <div id="leaderboard-tabs" className="flex border-b border-slate-200">
        <button
          id="tab-students"
          onClick={() => setActiveTab('students')}
          className={`px-6 py-3 font-semibold text-sm border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'students'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          Students Leaderboard
        </button>
        <button
          id="tab-schools"
          onClick={() => setActiveTab('schools')}
          className={`px-6 py-3 font-semibold text-sm border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'schools'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <SchoolIcon className="w-4 h-4" />
          School Leaderboard
        </button>
      </div>

      {/* Top 3 Celebratory Podium */}
      <div id="leaderboard-podium" className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
        {activeTab === 'students' ? (
          // Student Podium (Top 3)
          studentRankings.slice(0, 3).map((item, index) => {
            const rank = index + 1;
            return (
              <div
                key={item.id}
                id={`podium-student-${rank}`}
                className={`bg-white border rounded-3xl p-6 text-center shadow-xs relative overflow-hidden flex flex-col justify-between transition-transform hover:scale-[1.01] ${
                  rank === 1 ? 'border-amber-300 ring-1 ring-amber-200/50 bg-amber-50/10' : 'border-slate-150'
                }`}
              >
                {/* Rank Trophy Floating Background */}
                <span className="absolute top-4 right-4 text-3xl opacity-80">{rank === 1 ? '🏆' : rank === 2 ? '🥈' : '🥉'}</span>

                <div className="space-y-3">
                  <div className="mx-auto w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg border bg-gradient-to-br from-slate-50 to-slate-100 shadow-xs">
                    {getRankIndicatorEmoji(rank)}
                  </div>
                  <div>
                    <h4 id={`podium-stud-name-${rank}`} className="font-bold text-slate-800 text-lg leading-tight">{item.name}</h4>
                    <p className="text-xs text-slate-400 mt-1 lines-clamp-1">{item.schoolName}</p>
                    <p className="text-[10px] text-slate-500 font-mono mt-0.5">ID: {item.id}</p>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-100 flex justify-between items-center text-left">
                  <div>
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Total Deposit</p>
                    <p id={`podium-stud-total-${rank}`} className="text-xl font-black text-slate-800">{item.totalWeight.toFixed(1)} <span className="text-xs font-normal">kg</span></p>
                  </div>
                  <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold uppercase tracking-wider ${
                    rank === 1 ? 'bg-amber-100 text-amber-800' : rank === 2 ? 'bg-slate-100 text-slate-700' : 'bg-orange-50 text-orange-800'
                  }`}>
                    {rank === 1 ? 'Champion' : rank === 2 ? 'Runner Up' : 'Bronze Star'}
                  </span>
                </div>
              </div>
            );
          })
        ) : (
          // School Podium (Top 3)
          schoolRankings.slice(0, 3).map((item, index) => {
            const rank = index + 1;
            return (
              <div
                key={item.id}
                id={`podium-school-${rank}`}
                className={`bg-white border rounded-3xl p-6 text-center shadow-xs relative overflow-hidden flex flex-col justify-between transition-transform hover:scale-[1.01] ${
                  rank === 1 ? 'border-amber-300 ring-1 ring-amber-200/50 bg-amber-50/10' : 'border-slate-150'
                }`}
              >
                {/* Floating Rank Indicator */}
                <span className="absolute top-4 right-4 text-3xl opacity-80">{rank === 1 ? '🏫🏆' : rank === 2 ? '🏫🥈' : '🏫🥉'}</span>

                <div className="space-y-3">
                  <div className="mx-auto w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg border bg-gradient-to-br from-slate-50 to-slate-100 shadow-xs">
                    {getRankIndicatorEmoji(rank)}
                  </div>
                  <div>
                    <h4 id={`podium-school-name-${rank}`} className="font-extrabold text-slate-800 text-base leading-tight max-w-[190px] mx-auto truncate" title={item.name}>{item.name}</h4>
                    <p className="text-xs text-emerald-600 font-semibold mt-1 flex items-center justify-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      {item.studentCount} representation
                    </p>
                    <p className="text-[10px] text-slate-500 font-mono mt-0.5">ID: {item.id}</p>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-100 flex justify-between items-center text-left">
                  <div>
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Total School Cumulative</p>
                    <p id={`podium-school-total-${rank}`} className="text-xl font-black text-slate-800">{item.totalWeight.toFixed(1)} <span className="text-xs font-normal">kg</span></p>
                  </div>
                  <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold uppercase tracking-wider ${
                    rank === 1 ? 'bg-amber-100 text-amber-800' : rank === 2 ? 'bg-slate-100 text-slate-700' : 'bg-orange-50 text-orange-850'
                  }`}>
                    {rank === 1 ? 'Top School' : rank === 2 ? 'Silver Leader' : 'Bronze Leader'}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Complete Rankings Tables */}
      <div id="full-rankings-card" className="bg-white border border-slate-100 rounded-3xl shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 bg-slate-50/50">
          <h3 className="text-sm font-bold text-slate-705 uppercase tracking-wider flex items-center gap-2">
            <Flame className="w-4 h-4 text-orange-500 animate-pulse" />
            Full Leaderboard Standings
          </h3>
        </div>

        {activeTab === 'students' ? (
          // Full Students Rankings
          studentRankings.length === 0 ? (
            <div className="p-12 text-center text-slate-500">
              <p className="text-sm">No student rankings available yet. Create collection entries first!</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-slate-700">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200/60 text-xs font-bold text-slate-500 uppercase tracking-widest">
                    <th className="py-3 px-6 text-center w-24">Rank</th>
                    <th className="py-3 px-6">Pupil Name</th>
                    <th className="py-3 px-6">Participating School</th>
                    <th className="py-3 px-6 text-right">Paper Waste Total</th>
                    <th className="py-3 px-6 text-right">Plastic Waste Total</th>
                    <th className="py-3 px-6 text-right text-emerald-800 font-bold">Total Weight Collected</th>
                    <th className="py-3 px-6">Eco-Rating Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {studentRankings.map((item, index) => {
                    const rank = index + 1;
                    // Auto recalculate performance based on cumulative weight to check how rich they are
                    const rating = item.totalWeight > 20 ? 'Excellent' : item.totalWeight > 10 ? 'Best' : item.totalWeight > 5 ? 'Good' : 'Needs Improvement';
                    
                    return (
                      <tr key={item.id} id={`full-rank-stud-${item.id}`} className="hover:bg-slate-50/50 transition-colors">
                        <td className="py-4 px-6 text-center">
                          <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full text-xs font-bold border ${getRankBadge(rank)}`}>
                            {getRankIndicatorEmoji(rank)}
                          </span>
                        </td>
                        <td className="py-4 px-6 font-bold text-slate-800">
                          {item.name}
                          <span className="block text-[10px] text-slate-400 font-mono font-normal mt-0.5">{item.id}</span>
                        </td>
                        <td className="py-4 px-6 text-slate-500 font-semibold text-xs truncate max-w-xs">
                          {item.schoolName}
                        </td>
                        <td className="py-4 px-6 text-right font-mono text-slate-600 text-xs">
                          {item.paperTotal.toFixed(1)} kg
                        </td>
                        <td className="py-4 px-6 text-right font-mono text-slate-600 text-xs">
                          {item.plasticTotal.toFixed(1)} kg
                        </td>
                        <td className="py-4 px-6 text-right font-mono text-emerald-800 font-black">
                          {item.totalWeight.toFixed(1)} kg
                        </td>
                        <td className="py-4 px-6">
                          <span className={`inline-flex px-2 px-2.5 py-0.5 rounded-full text-xs font-bold border ${
                            rating === 'Excellent' ? 'bg-emerald-50 text-emerald-700 border-emerald-250' :
                            rating === 'Best' ? 'bg-sky-50 text-sky-700 border-sky-250' :
                            rating === 'Good' ? 'bg-amber-50 text-amber-700 border-amber-250' :
                            'bg-rose-50 text-rose-700 border-rose-250'
                          }`}>
                            {rating}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )
        ) : (
          // Full School Rankings
          schoolRankings.length === 0 ? (
            <div className="p-12 text-center text-slate-500">
              <p className="text-sm">No school rankings available yet. Establish registered schools first!</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-slate-700">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200/60 text-xs font-bold text-slate-500 uppercase tracking-widest">
                    <th className="py-3 px-6 text-center w-24">Rank</th>
                    <th className="py-3 px-6">School Name</th>
                    <th className="py-3 px-6">Active Pupils</th>
                    <th className="py-3 px-6 text-right">Paper Waste Sum</th>
                    <th className="py-3 px-6 text-right">Plastic Waste Sum</th>
                    <th className="py-3 px-6 text-right text-emerald-800 font-bold">Cumulative Weight</th>
                    <th className="py-3 px-6">Championship Ratio</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {schoolRankings.map((item, index) => {
                    const rank = index + 1;
                    const performanceRatio = item.studentCount > 0 ? (item.totalWeight / item.studentCount).toFixed(1) : '0';
                    return (
                      <tr key={item.id} id={`full-rank-school-${item.id}`} className="hover:bg-slate-50/50 transition-colors">
                        <td className="py-4 px-6 text-center">
                          <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full text-xs font-bold border ${getRankBadge(rank)}`}>
                            {getRankIndicatorEmoji(rank)}
                          </span>
                        </td>
                        <td className="py-4 px-6 font-bold text-slate-850">
                          {item.name}
                          <span className="block text-[10px] text-slate-400 font-mono font-normal mt-0.5">ID: {item.id}</span>
                        </td>
                        <td className="py-4 px-6">
                          <div className="flex items-center gap-1 text-slate-755 font-semibold text-xs">
                            <Users className="w-3.5 h-3.5 text-slate-400" />
                            {item.studentCount} REPRESENTATIVES
                          </div>
                        </td>
                        <td className="py-4 px-6 text-right font-mono text-slate-600 text-xs">
                          {item.paperTotal.toFixed(1)} kg
                        </td>
                        <td className="py-4 px-6 text-right font-mono text-slate-600 text-xs">
                          {item.plasticTotal.toFixed(1)} kg
                        </td>
                        <td className="py-4 px-6 text-right font-mono text-emerald-800 font-black">
                          {item.totalWeight.toFixed(1)} kg
                        </td>
                        <td className="py-4 px-6 font-medium text-xs text-slate-500">
                          <span className="text-emerald-700 font-bold">{performanceRatio} kg </span>
                          <span>avg / student</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )
        )}
      </div>
    </div>
  );
}
