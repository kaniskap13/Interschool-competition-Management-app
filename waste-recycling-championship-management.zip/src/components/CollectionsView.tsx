/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Student, CollectionEntry, School } from '../types';
import { calculatePerformance } from '../mockData';
import { Scale, Calendar, FileText, Globe, Plus, Edit2, Trash2, CheckCircle, AlertCircle, Sparkles, Search } from 'lucide-react';

interface CollectionsViewProps {
  entries: CollectionEntry[];
  students: Student[];
  schools: School[];
  onAddEntry: (entry: CollectionEntry) => void;
  onEditEntry: (entry: CollectionEntry) => void;
  onDeleteEntry: (id: string) => void;
}

export default function CollectionsView({ entries, students, schools, onAddEntry, onEditEntry, onDeleteEntry }: CollectionsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<CollectionEntry | null>(null);

  // Form States
  const [studentId, setStudentId] = useState('');
  const [collectionDate, setCollectionDate] = useState(new Date().toISOString().substring(0, 10));
  const [paperWeight, setPaperWeight] = useState<number | ''>('');
  const [plasticWeight, setPlasticWeight] = useState<number | ''>('');

  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'is-error' } | null>(null);

  const triggerNotification = (message: string, type: 'success' | 'is-error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  // Live Auto-populated and calculated states
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [liveTotalWeight, setLiveTotalWeight] = useState(0);
  const [livePerformance, setLivePerformance] = useState<'Excellent' | 'Best' | 'Good' | 'Needs Improvement'>('Needs Improvement');

  // Trigger when student selection changes
  useEffect(() => {
    const student = students.find((s) => s.id === studentId);
    setSelectedStudent(student || null);
  }, [studentId, students]);

  // Live total & performance calculation
  useEffect(() => {
    const paper = Number(paperWeight) || 0;
    const plastic = Number(plasticWeight) || 0;
    const total = paper + plastic;
    setLiveTotalWeight(total);
    setLivePerformance(calculatePerformance(total));
  }, [paperWeight, plasticWeight]);

  const handleOpenAdd = () => {
    if (students.length === 0) {
      triggerNotification('Please enroll at least one student before logging collections!', 'is-error');
      return;
    }
    setEditingEntry(null);
    setStudentId(students[0].id);
    setCollectionDate(new Date().toISOString().substring(0, 10));
    setPaperWeight('');
    setPlasticWeight('');
    setIsFormOpen(true);
  };

  const handleOpenEdit = (entry: CollectionEntry) => {
    setEditingEntry(entry);
    setStudentId(entry.studentId);
    setCollectionDate(entry.collectionDate);
    setPaperWeight(entry.paperWeight);
    setPlasticWeight(entry.plasticWeight);
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const paper = Number(paperWeight);
    const plastic = Number(plasticWeight);

    if (isNaN(paper) || paper < 0 || isNaN(plastic) || plastic < 0) {
      triggerNotification('Weights must be non-negative numbers', 'is-error');
      return;
    }

    if (paper === 0 && plastic === 0) {
      triggerNotification('Waste collection must have at least paper or plastic!', 'is-error');
      return;
    }

    if (!selectedStudent) {
      triggerNotification('Please select a valid student participant', 'is-error');
      return;
    }

    const total = paper + plastic;
    const perfRating = calculatePerformance(total);

    if (editingEntry) {
      // Editing
      const updatedEntry: CollectionEntry = {
        ...editingEntry,
        studentId: selectedStudent.id,
        studentName: selectedStudent.name,
        schoolId: selectedStudent.schoolId,
        schoolName: selectedStudent.schoolName,
        collectionDate,
        paperWeight: paper,
        plasticWeight: plastic,
        totalWeight: total,
        performance: perfRating,
      };
      onEditEntry(updatedEntry);
      triggerNotification(`Collection log updated successfully!`);
    } else {
      // Create auto id e.g. ENT-013
      let nextIdNum = 1;
      if (entries.length > 0) {
        const ids = entries
          .map((e) => parseInt(e.id.replace('ENT-', '')))
          .filter((n) => !isNaN(n));
        if (ids.length > 0) {
          nextIdNum = Math.max(...ids) + 1;
        }
      }
      const newId = `ENT-${nextIdNum.toString().padStart(3, '0')}`;

      const newEntry: CollectionEntry = {
        id: newId,
        studentId: selectedStudent.id,
        studentName: selectedStudent.name,
        schoolId: selectedStudent.schoolId,
        schoolName: selectedStudent.schoolName,
        collectionDate,
        paperWeight: paper,
        plasticWeight: plastic,
        totalWeight: total,
        performance: perfRating,
      };
      onAddEntry(newEntry);
      triggerNotification(`New log logged with ID ${newId}`);
    }

    setIsFormOpen(false);
  };

  const handleDelete = (id: string) => {
    onDeleteEntry(id);
  };

  const filteredEntries = entries.filter((e) =>
    e.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    e.schoolName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    e.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Styling rating color
  const getPerformanceBadge = (perf: string) => {
    switch (perf) {
      case 'Excellent':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Best':
        return 'bg-sky-50 text-sky-700 border-sky-200';
      case 'Good':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      default:
        return 'bg-rose-50 text-rose-700 border-rose-200';
    }
  };

  return (
    <div id="collections-view-wrapper" className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 id="collections-view-title" className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
            <Scale className="w-7 h-7 text-emerald-600" />
            Waste Collection Log Entries
          </h2>
          <p className="text-slate-500 text-sm mt-0.5">
            Log raw weight deposits, calculate environmental equivalents, and record achievements automatically.
          </p>
        </div>
        <button
          id="toggle-collection-form-btn"
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm rounded-xl shadow-md ... cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Log Collection Entry
        </button>
      </div>

      {notification && (
        <div
          id="collections-toast"
          className={`p-4 rounded-xl border flex items-center gap-3 animate-slideIn ${
            notification.type === 'success'
              ? 'bg-emerald-50 border-emerald-100 text-emerald-800'
              : 'bg-rose-50 border-rose-100 text-rose-800'
          }`}
        >
          {notification.type === 'success' ? <CheckCircle className="w-5 h-5 animate-bounce" /> : <AlertCircle className="w-5 h-5 text-rose-600" />}
          <span className="text-sm font-semibold">{notification.message}</span>
        </div>
      )}

      {/* Form Log Overlay Modal */}
      {isFormOpen && (
        <div id="col-modal-overlay" className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div id="col-modal-card" className="bg-white rounded-3xl shadow-xl border border-slate-100 w-full max-w-xl overflow-hidden animate-zoomIn flex flex-col">
            <div className="bg-emerald-600 text-white px-6 py-4 flex items-center justify-between flex-shrink-0">
              <h3 id="col-modal-header" className="text-lg font-bold">
                {editingEntry ? `Update Entry: ${editingEntry.id}` : 'Record Waste Recycling Deposit'}
              </h3>
              <button
                id="col-modal-close"
                onClick={() => setIsFormOpen(false)}
                className="text-emerald-100 hover:text-white text-sm font-semibold cursor-pointer"
              >
                Cancel
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Select Student */}
                <div className="md:col-span-2">
                  <label htmlFor="col-form-student" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Select Active Student *</label>
                  <select
                    id="col-form-student"
                    required
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 bg-slate-50 focus:bg-white rounded-lg text-sm focus:outline-none"
                  >
                    {students.map((st) => (
                      <option key={st.id} value={st.id}>
                        {st.name} ({st.id} - {st.schoolName})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Auto populated School (Readonly visual reminder) */}
                {selectedStudent && (
                  <div className="md:col-span-2 bg-emerald-50/50 rounded-xl p-3.5 border border-emerald-100/60">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Automated School Linkage</p>
                    <p className="text-xs font-bold text-emerald-800 mt-1">{selectedStudent.schoolName}</p>
                    <p className="text-[10px] text-slate-500 mt-0.5">{selectedStudent.grade} &middot; Section {selectedStudent.section}</p>
                  </div>
                )}

                {/* Collection Date */}
                <div className="md:col-span-2">
                  <label htmlFor="col-form-date" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Collection Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-2 text-slate-400 w-4 h-4" />
                    <input
                      id="col-form-date"
                      type="date"
                      required
                      value={collectionDate}
                      onChange={(e) => setCollectionDate(e.target.value)}
                      className="w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none"
                    />
                  </div>
                </div>

                {/* Paper Weight */}
                <div>
                  <label htmlFor="col-form-paper" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Paper Weight Collected (kg)</label>
                  <div className="relative">
                    <FileText className="absolute left-3 top-2 text-slate-400 w-4 h-4" />
                    <input
                      id="col-form-paper"
                      type="number"
                      step="0.1"
                      min="0"
                      value={paperWeight}
                      onChange={(e) => setPaperWeight(e.target.value === '' ? '' : parseFloat(e.target.value))}
                      placeholder="Paper weight in kg"
                      className="w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none"
                    />
                  </div>
                </div>

                {/* Plastic Weight */}
                <div>
                  <label htmlFor="col-form-plastic" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Plastic Weight Collected (kg)</label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-2 text-slate-400 w-4 h-4" />
                    <input
                      id="col-form-plastic"
                      type="number"
                      step="0.1"
                      min="0"
                      value={plasticWeight}
                      required
                      onChange={(e) => setPlasticWeight(e.target.value === '' ? '' : parseFloat(e.target.value))}
                      placeholder="Plastic weight in kg"
                      className="w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Dynamic live performance calculator display */}
              <div id="live-performance-badge-box" className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Live Performance Calculation</p>
                  <h4 className="text-xl font-bold text-slate-800 mt-1">{liveTotalWeight.toFixed(1)} <span className="text-xs font-normal">kg</span></h4>
                </div>
                {liveTotalWeight > 0 && (
                  <div className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 ${getPerformanceBadge(livePerformance)}`}>
                    <Sparkles className="w-3.5 h-3.5 animate-spin"/>
                    {livePerformance}
                  </div>
                )}
              </div>

              {/* Performance Rules Card */}
              <div className="p-3 bg-emerald-50/20 text-[11px] rounded-lg border border-emerald-500/10 text-emerald-800">
                <span className="font-bold">Rating Criteria:</span> Excellent &gt; 20kg &bull; Best &gt; 10kg &bull; Good &gt; 5kg &bull; Needs Improvement &le; 5kg
              </div>

              <div id="col-form-footer" className="mt-6 flex justify-end gap-3 pt-4 border-t border-slate-100 flex-shrink-0">
                <button
                  id="col-cancel-btn"
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-750 text-sm font-semibold rounded-lg hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  id="col-save-btn"
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-lg cursor-pointer"
                >
                  {editingEntry ? 'Update Entry Logs' : 'Submit Entry Logs'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Database Search & List panel */}
      <div id="collections-table-card" className="bg-white border border-slate-100 rounded-3xl shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              id="col-search-box"
              type="text"
              placeholder="Search by student, school name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 border border-slate-200 text-sm rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
          <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">
            Showing {filteredEntries.length} of {entries.length} deposit logs
          </span>
        </div>

        {filteredEntries.length === 0 ? (
          <div id="collections-empty-state" className="p-12 text-center text-slate-500">
            <Scale className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-sm font-bold">No collections found matching search criteria.</p>
          </div>
        ) : (
          <div className="overflow-x-auto text-slate-700">
            <table id="collections-table" className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200/60 text-xs font-bold text-slate-500 uppercase tracking-widest">
                  <th className="py-3.5 px-6">Entry ID</th>
                  <th className="py-3.5 px-6">Student Representative</th>
                  <th className="py-3.5 px-6">School Affiliation</th>
                  <th className="py-3.5 px-6">Collection Date</th>
                  <th className="py-3.5 px-6">Weights & Deposit (Paper/Plastic/Total)</th>
                  <th className="py-3.5 px-6">Performance</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100/80 text-sm">
                {filteredEntries.map((col) => (
                  <tr key={col.id} id={`col-row-${col.id}`} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-4 px-6 font-mono font-semibold text-xs text-slate-500">
                      {col.id}
                    </td>
                    <td className="py-4 px-6 font-bold text-slate-800">
                      {col.studentName}
                    </td>
                    <td className="py-4 px-6 text-slate-500 text-xs truncate max-w-[200px] font-semibold">
                      {col.schoolName}
                    </td>
                    <td className="py-4 px-6 text-slate-600 font-mono text-xs font-semibold">
                      {col.collectionDate}
                    </td>
                    <td className="py-4 px-6 font-medium text-xs text-slate-600 space-y-1">
                      <div>Paper: <strong className="text-slate-800">{col.paperWeight.toFixed(1)} kg</strong></div>
                      <div>Plastic: <strong className="text-slate-800">{col.plasticWeight.toFixed(1)} kg</strong></div>
                      <div className="border-t border-slate-100 pt-1">Total: <strong className="text-emerald-700 font-bold">{col.totalWeight.toFixed(1)} kg</strong></div>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold border ${getPerformanceBadge(col.performance)}`}>
                        {col.performance}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <div className="inline-flex gap-1.5">
                        <button
                          id={`col-edit-${col.id}`}
                          onClick={() => handleOpenEdit(col)}
                          title="Edit Deposit Records"
                          className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-all cursor-pointer"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          id={`col-delete-${col.id}`}
                          onClick={() => handleDelete(col.id)}
                          title="Delete Record"
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
