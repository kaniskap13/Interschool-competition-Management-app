/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ViewType } from '../types';
import {
  LayoutDashboard,
  School,
  Users,
  Scale,
  Database,
  Trophy,
  FileBarChart,
  LogOut,
  Leaf,
  Menu,
  X
} from 'lucide-react';

interface SidebarProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
  onLogout: () => void;
}

export default function Sidebar({ currentView, onViewChange, onLogout }: SidebarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const menuItems = [
    { name: 'Dashboard', icon: LayoutDashboard, view: 'Dashboard' as ViewType },
    { name: 'School Registration', icon: School, view: 'Schools' as ViewType },
    { name: 'Student Registration', icon: Users, view: 'Students' as ViewType },
    { name: 'Waste Collection Entry', icon: Scale, view: 'Collections' as ViewType },
    { name: 'Database Viewer', icon: Database, view: 'Database' as ViewType },
    { name: 'Leaderboard', icon: Trophy, view: 'Leaderboard' as ViewType },
    { name: 'Reports & Analytics', icon: FileBarChart, view: 'Reports' as ViewType },
    { name: 'Environmental Impact', icon: Leaf, view: 'Impact' as ViewType },
  ];

  // Dynamic quick stat calculation
  let paperPct = 62;
  try {
    const storedEntries = localStorage.getItem('rc_entries');
    if (storedEntries) {
      const parsed = JSON.parse(storedEntries);
      const totalPaper = parsed.reduce((sum: number, e: any) => sum + (Number(e.paperWeight) || 0), 0);
      const totalPlastic = parsed.reduce((sum: number, e: any) => sum + (Number(e.plasticWeight) || 0), 0);
      const total = totalPaper + totalPlastic;
      if (total > 0) {
        paperPct = Math.round((totalPaper / total) * 100);
      }
    }
  } catch (err) {
    // Fail-safe default
  }

  return (
    <>
      {/* Mobile Top Bar */}
      <div id="mobile-top-bar" className="md:hidden bg-[#022c22] border-b border-emerald-900 h-16 px-4 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-emerald-500 rounded-lg text-white">
            <Leaf className="w-5 h-5" />
          </div>
          <span className="font-bold text-emerald-50 text-sm tracking-tight">Eco Championship</span>
        </div>
        <button
          id="menu-toggle-btn"
          onClick={() => setIsOpen(!isOpen)}
          className="p-2 rounded-lg text-emerald-150 hover:bg-emerald-900 transition-colors"
        >
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Sidebar background overlay for mobile */}
      {isOpen && (
        <div
          id="sidebar-overlay"
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 bg-[#022c22]/60 backdrop-blur-xs z-40 md:hidden"
        />
      )}

      {/* Sidebar Navigation */}
      <aside
        id="app-sidebar"
        className={`fixed md:sticky top-0 left-0 h-screen w-64 bg-[#022c22] text-emerald-100 flex flex-col transition-transform duration-300 transform z-50 md:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } border-r border-emerald-900/60`}
      >
        {/* Brand Header */}
        <div id="sidebar-header" className="h-20 flex items-center gap-3 px-6 border-b border-emerald-900/60">
          <div className="p-2.5 bg-emerald-500 rounded-xl text-white shadow-lg shadow-emerald-500/20">
            <Leaf className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-extrabold text-white tracking-tight leading-tight uppercase">Recycle</h1>
            <p className="text-[10px] font-semibold text-emerald-400 tracking-wider uppercase">Championship</p>
          </div>
        </div>

        {/* Menu Items */}
        <nav id="sidebar-nav-list" className="flex-1 py-6 px-4 space-y-1.5 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.view;
            return (
              <button
                id={`nav-item-${item.view.toLowerCase()}`}
                key={item.view}
                onClick={() => {
                  onViewChange(item.view);
                  setIsOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-800/60 text-white shadow-md shadow-emerald-950/40 border border-emerald-700/50'
                    : 'text-emerald-100/70 hover:bg-emerald-900/40 hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 flex-shrink-0 transition-colors ${isActive ? 'text-emerald-400' : 'text-emerald-100/40'}`} />
                <span className="truncate">{item.name}</span>
                {isActive && (
                  <span className="ml-auto w-1.5 h-1.5 bg-emerald-450 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Quick Stat component matching exactly the designer specification */}
        <div className="p-4 border-t border-emerald-900/60">
          <div className="bg-emerald-900/40 p-4 rounded-xl border border-emerald-800/45">
            <div className="text-[10px] text-emerald-400 font-extrabold tracking-widest mb-1.5 uppercase">QUICK STAT</div>
            <div className="text-xs text-emerald-50 leading-relaxed font-semibold">
              Paper vs Plastic Ratio:{' '}
              <span className="text-emerald-300 font-bold underline underline-offset-4 decoration-emerald-500">
                {paperPct}%
              </span>
            </div>
          </div>
        </div>

        {/* User profile / Logout footer */}
        <div id="sidebar-footer" className="p-4 border-t border-emerald-900/60 bg-emerald-950/55">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 text-sm font-semibold flex-shrink-0">
                AD
              </div>
              <div className="min-w-0">
                <p className="text-xs font-black text-white truncate leading-tight">Admin Portal</p>
                <p className="text-[10px] text-emerald-400 truncate mt-0.5 font-semibold">Championship Mode</p>
              </div>
            </div>
            <button
              id="logout-button"
              onClick={onLogout}
              title="Logout"
              className="p-2 rounded-lg text-emerald-300 hover:bg-emerald-900/70 hover:text-red-400 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
