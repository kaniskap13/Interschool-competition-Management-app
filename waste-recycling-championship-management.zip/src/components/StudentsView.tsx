/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Student, School } from '../types';
import { Users, Edit2, Trash2, Phone, Search, Plus, CheckCircle, AlertTriangle, ShieldCheck, HelpCircle } from 'lucide-react';

interface StudentsViewProps {
  students: Student[];
  schools: School[];
  onAddStudent: (student: Student) => void;
  onEditStudent: (student: Student) => void;
  onDeleteStudent: (id: string) => void;
}

export default function StudentsView({ students, schools, onAddStudent, onEditStudent, onDeleteStudent }: StudentsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [schoolFilter, setSchoolFilter] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // Form States
  const [name, setName] = useState('');
  const [grade, setGrade] = useState('Grade 8');
  const [section, setSection] = useState('A');
  const [gender, setGender] = useState('Male');
  const [schoolId, setSchoolId] = useState('');
  const [parentMobile, setParentMobile] = useState('');

  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const triggerNotification = (message: string, type: 'success' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  const handleOpenAdd = () => {
    if (schools.length === 0) {
      triggerNotification('Please register at least one school before adding students!', 'error');
      return;
    }
    setEditingStudent(null);
    setName('');
    setGrade('Grade 8');
    setSection('A');
    setGender('Male');
    setSchoolId(schools[0].id);
    setParentMobile('');
    setIsFormOpen(true);
  };

  const handleOpenEdit = (student: Student) => {
    setEditingStudent(student);
    setName(student.name);
    setGrade(student.grade);
    setSection(student.section);
    setGender(student.gender);
    setSchoolId(student.schoolId);
    setParentMobile(student.parentMobile);
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim() || !schoolId || !parentMobile.trim()) {
      triggerNotification('Please complete all mandatory fields', 'error');
      return;
    }

    const selectedSchool = schools.find((s) => s.id === schoolId);
    const schoolName = selectedSchool ? selectedSchool.name : 'Unknown School';

    if (editingStudent) {
      const updatedStudent: Student = {
        ...editingStudent,
        name,
        grade,
        section,
        gender,
        schoolId,
        schoolName,
        parentMobile,
      };
      onEditStudent(updatedStudent);
      triggerNotification(`${name} registration updated successfully`);
    } else {
      // Auto-generate STU-xxx ID
      let nextIdNum = 1;
      if (students.length > 0) {
        const ids = students
          .map((s) => parseInt(s.id.replace('STU-', '')))
          .filter((n) => !isNaN(n));
        if (ids.length > 0) {
          nextIdNum = Math.max(...ids) + 1;
        }
      }
      const newId = `STU-${nextIdNum.toString().padStart(3, '0')}`;

      const newStudent: Student = {
        id: newId,
        name,
        grade,
        section,
        gender,
        schoolId,
        schoolName,
        parentMobile,
      };
      onAddStudent(newStudent);
      triggerNotification(`${name} registered successfully with ID ${newId}`);
    }

    setIsFormOpen(false);
  };

  const handleDelete = (id: string, label: string) => {
    onDeleteStudent(id);
  };

  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.grade.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSchool = !schoolFilter || s.schoolId === schoolFilter;
    return matchesSearch && matchesSchool;
  });

  return (
    <div id="students-view-wrapper" className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 id="students-view-title" className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
            <Users className="w-7 h-7 text-emerald-600" />
            Student Registration
          </h2>
          <p className="text-slate-500 text-sm mt-0.5">
            Register and manage active pupils representing their competitive schools.
          </p>
        </div>
        <button
          id="toggle-student-form-btn"
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-emerald-600/10 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Register Student
        </button>
      </div>

      {notification && (
        <div
          id="students-toast"
          className={`p-4 rounded-xl border flex items-center gap-3 animate-slideIn ${
            notification.type === 'success'
              ? 'bg-emerald-50 border-emerald-100 text-emerald-800'
              : 'bg-rose-50 border-rose-100 text-rose-800'
          }`}
        >
          {notification.type === 'success' ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
          <span className="text-sm font-medium">{notification.message}</span>
        </div>
      )}

      {/* Form Modal */}
      {isFormOpen && (
        <div id="student-modal-overlay" className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div id="student-modal-card" className="bg-white rounded-3xl shadow-xl w-full max-w-xl overflow-hidden animate-zoomIn">
            <div className="bg-emerald-600 text-white px-6 py-4 flex items-center justify-between">
              <h3 id="student-modal-header" className="text-lg font-bold">
                {editingStudent ? `Edit Student: ${editingStudent.id}` : 'Enroll New Student Participant'}
              </h3>
              <button
                id="student-modal-close"
                onClick={() => setIsFormOpen(false)}
                className="text-emerald-100 hover:text-white text-sm font-semibold cursor-pointer"
              >
                Cancel
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label htmlFor="student-form-name" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Full Student Name *</label>
                  <input
                    id="student-form-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. John Doe"
                    className="w-full px-3 py-2 border border-slate-200 bg-slate-50 focus:bg-white rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label htmlFor="student-form-school" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Affiliated School *</label>
                  <select
                    id="student-form-school"
                    required
                    value={schoolId}
                    onChange={(e) => setSchoolId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 bg-slate-50 focus:bg-white rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    {schools.map((sch) => (
                      <option key={sch.id} value={sch.id}>
                        {sch.name} ({sch.id})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="student-form-mobile" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Parent Mobile Number *</label>
                  <input
                    id="student-form-mobile"
                    type="tel"
                    required
                    value={parentMobile}
                    onChange={(e) => setParentMobile(e.target.value)}
                    placeholder="Emergency Contact"
                    className="w-full px-3 py-2 border border-slate-200 bg-slate-50 focus:bg-white rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label htmlFor="student-form-grade" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Grade / Standard</label>
                  <input
                    id="student-form-grade"
                    type="text"
                    value={grade}
                    onChange={(e) => setGrade(e.target.value)}
                    placeholder="e.g. Grade 8, Standard 10"
                    className="w-full px-3 py-2 border border-slate-200 bg-slate-50 focus:bg-white rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="student-form-section" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Section</label>
                    <input
                      id="student-form-section"
                      type="text"
                      value={section}
                      onChange={(e) => setSection(e.target.value)}
                      placeholder="e.g. A, B"
                      className="w-full px-3 py-2 border border-slate-200 bg-slate-50 focus:bg-white rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label htmlFor="student-form-gender" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Gender</label>
                    <select
                      id="student-form-gender"
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 bg-slate-50 focus:bg-white rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>
              </div>

              <div id="student-form-footer" className="mt-6 flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  id="student-cancel-btn"
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-750 text-sm font-semibold rounded-lg hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  id="student-save-btn"
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-lg cursor-pointer shadow-xs"
                >
                  {editingStudent ? 'Apply Changes' : 'Enroll Student'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Main Filter and Database Table Card */}
      <div id="students-table-card" className="bg-white border border-slate-100 rounded-3xl shadow-xs overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3 w-full lg:max-w-2xl">
            {/* Search Input */}
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input
                id="student-search-box"
                type="text"
                placeholder="Search pupil name, standard, ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 border border-slate-200 text-sm rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>

            {/* School Filter Dropdown */}
            <select
              id="student-school-filter"
              value={schoolFilter}
              onChange={(e) => setSchoolFilter(e.target.value)}
              className="px-3 py-2 border border-slate-200 text-sm bg-slate-50 hover:bg-slate-100 rounded-xl focus:outline-none"
            >
              <option value="">All Schools</option>
              {schools.map((sc) => (
                <option key={sc.id} value={sc.id}>
                  {sc.name}
                </option>
              ))}
            </select>
          </div>

          <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">
            {filteredStudents.length} Students Listed
          </span>
        </div>

        {filteredStudents.length === 0 ? (
          <div id="students-empty-state" className="p-16 text-center text-slate-500">
            <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-sm font-bold">No students found matching your criteria.</p>
            <p className="text-xs text-slate-400 mt-1">Try register a new student or relaxing filters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto text-slate-700">
            <table id="students-table" className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200/60 text-xs font-bold text-slate-500 uppercase tracking-widest">
                  <th className="py-3.5 px-6">Student ID</th>
                  <th className="py-3.5 px-6">Full Name</th>
                  <th className="py-3.5 px-6">School Affiliation</th>
                  <th className="py-3.5 px-6">Grade / Section</th>
                  <th className="py-3.5 px-6">Emergency Contact</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100/80 text-sm">
                {filteredStudents.map((stud) => (
                  <tr key={stud.id} id={`student-row-${stud.id}`} className="hover:bg-slate-50/40 transition-colors">
                    <td className="py-4 px-6 font-mono font-bold text-slate-500 text-xs text-emerald-800">
                      {stud.id}
                    </td>
                    <td className="py-4 px-6">
                      <div className="font-bold text-slate-800 flex items-center gap-2">
                        <span className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black text-white ${
                          stud.gender === 'Female' ? 'bg-indigo-500' : stud.gender === 'Male' ? 'bg-emerald-500' : 'bg-slate-500'
                        }`}>
                          {stud.name.substring(0, 1).toUpperCase()}
                        </span>
                        {stud.name}
                      </div>
                    </td>
                    <td className="py-4 px-6 text-slate-600 font-semibold text-xs translate-y-0.5 max-w-xs truncate">
                      {stud.schoolName}
                    </td>
                    <td className="py-4 px-6 space-x-1 font-medium">
                      <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-xs font-bold">
                        {stud.grade}
                      </span>
                      <span className="px-2 py-0.5 bg-amber-50 text-amber-700 rounded-md text-xs font-bold">
                        Sec {stud.section}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-slate-600 font-mono text-xs flex items-center gap-1.5 matches-call font-medium">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        {stud.parentMobile}
                      </div>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <div className="inline-flex gap-1.5">
                        <button
                          id={`student-edit-${stud.id}`}
                          onClick={() => handleOpenEdit(stud)}
                          title="Edit Student Info"
                          className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-all cursor-pointer"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          id={`student-delete-${stud.id}`}
                          onClick={() => handleDelete(stud.id, stud.name)}
                          title="Delete Record"
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
