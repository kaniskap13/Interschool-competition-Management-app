/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { School, Student, CollectionEntry } from '../types';
import {
  School as SchoolIcon,
  Users,
  Scale,
  Leaf,
  Droplet,
  Globe,
  Award,
  Zap,
  CheckCircle,
  TrendingUp,
  FileText
} from 'lucide-react';

interface DashboardViewProps {
  schools: School[];
  students: Student[];
  entries: CollectionEntry[];
  onViewChange: (view: any) => void;
}

export default function DashboardView({ schools, students, entries, onViewChange }: DashboardViewProps) {
  // Metric Calculations
  const totalSchools = schools.length;
  const totalStudents = students.length;

  const totalPaper = entries.reduce((sum, e) => sum + e.paperWeight, 0);
  const totalPlastic = entries.reduce((sum, e) => sum + e.plasticWeight, 0);
  const totalWeight = totalPaper + totalPlastic;

  const waterSaved = totalPaper * 17; // 1kg Paper = 17 Liters water
  const co2Reduced = totalPlastic * 6; // 1kg Plastic = 6kg CO2 emissions reduced

  // High performance calculation
  // Top Performing Student
  const studentTotals: { [key: string]: { name: string; school: string; total: number } } = {};
  entries.forEach((e) => {
    if (!studentTotals[e.studentId]) {
      studentTotals[e.studentId] = { name: e.studentName, school: e.schoolName, total: 0 };
    }
    studentTotals[e.studentId].total += e.totalWeight;
  });

  let topStudent = { name: 'N/A', school: 'N/A', total: 0 };
  Object.values(studentTotals).forEach((s) => {
    if (s.total > topStudent.total) {
      topStudent = s;
    }
  });

  // Top Performing School
  const schoolTotals: { [key: string]: { name: string; total: number } } = {};
  entries.forEach((e) => {
    if (!schoolTotals[e.schoolId]) {
      schoolTotals[e.schoolId] = { name: e.schoolName, total: 0 };
    }
    schoolTotals[e.schoolId].total += e.totalWeight;
  });

  let topSchool = { name: 'N/A', total: 0 };
  Object.values(schoolTotals).forEach((sc) => {
    if (sc.total > topSchool.total) {
      topSchool = sc;
    }
  });

  // Equivalent estimates for environmental rewards
  const treesSaved = Math.round((totalPaper * 0.017) * 10) / 10; // ~17 trees per ton (1000kg) of paper
  const plasticBottlesPrevented = Math.round(totalPlastic * 40); // 1kg of plastic waste is approx 40 bottles

  return (
    <div id="dashboard-view-wrapper" className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 id="dashboard-view-title" className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
            Championship Dashboard
          </h2>
          <p className="text-slate-500 mt-1 text-sm">
            Live overview of schools, active pupils, and cumulative recycling impacts.
          </p>
        </div>
        <div className="flex gap-3">
          <button
            id="register-school-quick-btn"
            onClick={() => onViewChange('Schools')}
            className="flex items-center gap-2 px-4 py-2 border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-sm font-semibold rounded-xl transition-all shadow-xs cursor-pointer"
          >
            <SchoolIcon className="w-4 h-4 text-emerald-500" />
            + Register School
          </button>
          <button
            id="add-entry-quick-btn"
            onClick={() => onViewChange('Collections')}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-xl shadow-md shadow-emerald-600/10 transition-all cursor-pointer"
          >
            <Scale className="w-4 h-4" />
            + Waste Entry
          </button>
        </div>
      </div>

      {/* Primary Statistics Grid */}
      <div id="stats-cards-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
        {/* Total Schools */}
        <div id="card-total-schools" className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-50 rounded-full translate-x-8 -translate-y-8 group-hover:bg-emerald-100/60 transition-colors" />
          <div className="relative z-10">
            <div className="p-2 bg-emerald-50 text-emerald-600 w-fit rounded-lg mb-4">
              <SchoolIcon className="w-5 h-5" />
            </div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Schools Registered</p>
            <h3 className="text-2xl font-bold text-slate-800 mt-1">{totalSchools}</h3>
            <span className="text-[10px] text-emerald-600 font-medium flex items-center gap-0.5 mt-2">
              <CheckCircle className="w-3 h-3" /> Active Participants
            </span>
          </div>
        </div>

        {/* Total Students */}
        <div id="card-total-students" className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-50 rounded-full translate-x-8 -translate-y-8 group-hover:bg-indigo-100/60 transition-colors" />
          <div className="relative z-10">
            <div className="p-2 bg-indigo-50 text-indigo-600 w-fit rounded-lg mb-4">
              <Users className="w-5 h-5" />
            </div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Students Active</p>
            <h3 className="text-2xl font-bold text-slate-800 mt-1">{totalStudents}</h3>
            <span className="text-[10px] text-indigo-600 font-medium flex items-center gap-0.5 mt-2">
              <Zap className="w-3 h-3" /> Pupil Eco-Champions
            </span>
          </div>
        </div>

        {/* Paper Collected */}
        <div id="card-paper-collected" className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-50 rounded-full translate-x-8 -translate-y-8 group-hover:bg-amber-100/60 transition-colors" />
          <div className="relative z-10">
            <div className="p-2 bg-amber-50 text-amber-600 w-fit rounded-lg mb-4">
              <FileText className="w-5 h-5" />
            </div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Paper Waste</p>
            <h3 className="text-2xl font-bold text-slate-800 mt-1">{totalPaper.toFixed(1)} <span className="text-sm font-normal text-slate-500">kg</span></h3>
            <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
              <div 
                className="bg-amber-500 h-full rounded-full transition-all duration-500" 
                style={{ width: `${totalWeight > 0 ? (totalPaper / totalWeight) * 100 : 0}%` }}
              />
            </div>
          </div>
        </div>

        {/* Plastic Collected */}
        <div id="card-plastic-collected" className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs hover:shadow-md transition-shadow relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-sky-50 rounded-full translate-x-8 -translate-y-8 group-hover:bg-sky-100/60 transition-colors" />
          <div className="relative z-10">
            <div className="p-2 bg-sky-50 text-sky-600 w-fit rounded-lg mb-4">
              <Globe className="w-5 h-5" />
            </div>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Plastic Waste</p>
            <h3 className="text-2xl font-bold text-slate-800 mt-1">{totalPlastic.toFixed(1)} <span className="text-sm font-normal text-slate-500">kg</span></h3>
            <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
              <div 
                className="bg-sky-500 h-full rounded-full transition-all duration-500" 
                style={{ width: `${totalWeight > 0 ? (totalPlastic / totalWeight) * 100 : 0}%` }}
              />
            </div>
          </div>
        </div>

        {/* Total Collected */}
        <div id="card-total-collected" className="bg-emerald-600 p-6 rounded-2xl text-white shadow-lg shadow-emerald-500/20 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/40 rounded-full translate-x-8 -translate-y-8 group-hover:bg-emerald-500/60 transition-colors" />
          <div className="relative z-10">
            <div className="p-2 bg-emerald-500/40 text-white w-fit rounded-lg mb-4">
              <Scale className="w-5 h-5" />
            </div>
            <p className="text-xs font-bold text-emerald-100 uppercase tracking-wider">Cumulative Waste</p>
            <h3 className="text-3xl font-extrabold mt-1">{totalWeight.toFixed(1)} <span className="text-base font-medium text-emerald-100">kg</span></h3>
            <p className="text-[10px] text-emerald-100/90 mt-2 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5" /> Environmental Recovery
            </p>
          </div>
        </div>
      </div>

      {/* Environmental Impact Showcase */}
      <div id="environmental-impact-showcase" className="bg-slate-900 rounded-3xl p-6 md:p-8 text-white border border-slate-800 shadow-xl overflow-hidden relative">
        {/* Background blobs */}
        <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl -translate-y-1/2 pointer-events-none" />
        <div className="absolute bottom-[-100px] right-[-100px] w-96 h-96 bg-blue-505/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="max-w-xl">
            <span className="px-3 py-1 bg-emerald-500/25 text-emerald-400 font-bold text-xs tracking-wider uppercase rounded-full border border-emerald-500/20">
              Environmental Conservation Impact
            </span>
            <h3 className="text-2xl md:text-3xl font-bold mt-4 tracking-tight leading-tight">
              Recycling translates to instant environmental recovery!
            </h3>
            <p className="text-slate-400 text-sm mt-3 leading-relaxed">
              By collecting recyclable paper and plastic across all schools in the competition, we preserve vital water resources and systematically eliminate carbon greenhouse boundaries.
            </p>

            <div className="grid grid-cols-2 gap-6 mt-8">
              <div id="impact-water-module" className="flex items-start gap-4">
                <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-500/10">
                  <Droplet className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Water Saved</h4>
                  <p className="text-2xl font-extrabold text-white mt-1">{waterSaved.toLocaleString()} <span className="text-xs font-semibold text-emerald-400">Liters</span></p>
                  <p className="text-[10px] text-slate-500 mt-1">17L preserved per kg of paper</p>
                </div>
              </div>

              <div id="impact-co2-module" className="flex items-start gap-4">
                <div className="p-3 bg-blue-500/20 text-blue-400 rounded-2xl border border-blue-500/10">
                  <Globe className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">CO₂ Reduced</h4>
                  <p className="text-2xl font-extrabold text-white mt-1">{co2Reduced.toLocaleString()} <span className="text-xs font-semibold text-blue-400">kg</span></p>
                  <p className="text-[10px] text-slate-500 mt-1">6kg greenhouse emission cut per kg of plastic</p>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Equivalent Display */}
          <div className="w-full lg:max-w-md bg-slate-950/40 border border-slate-800 p-6 rounded-2xl">
            <h4 className="text-sm font-bold text-slate-200 tracking-wide border-b border-slate-800 pb-3">Real-world Equivalents</h4>
            <div className="space-y-4 mt-4">
              <div id="tree-saving-row" className="flex items-center gap-4 py-1.5">
                <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400 font-bold flex-shrink-0">
                  🌲
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-400 font-medium">Calculated Trees Saved</p>
                  <p className="text-sm font-bold text-slate-200">{treesSaved > 0 ? `${treesSaved} mature trees` : 'No paper collected yet'}</p>
                </div>
                {treesSaved > 0 && <span className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded-md">Saved</span>}
              </div>

              <div id="bottle-saving-row" className="flex items-center gap-4 py-1.5">
                <div className="w-10 h-10 rounded-full bg-sky-500/10 flex items-center justify-center text-sky-400 font-bold flex-shrink-0">
                  🥤
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-400 font-medium">Sealed Bottles Diverted</p>
                  <p className="text-sm font-bold text-slate-200">{plasticBottlesPrevented > 0 ? `${plasticBottlesPrevented.toLocaleString()} plastic bottles` : 'No plastic collected yet'}</p>
                </div>
                {plasticBottlesPrevented > 0 && <span className="text-[10px] px-2 py-0.5 bg-sky-500/20 text-sky-400 rounded-md">Diverted</span>}
              </div>

              <div id="energy-saving-row" className="flex items-center gap-4 py-1.5">
                <div className="w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-400 font-bold flex-shrink-0">
                  💡
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-400 font-medium">Potential Electricity Saved</p>
                  <p className="text-sm font-bold text-slate-200">{totalWeight > 0 ? `${Math.round(totalWeight * 3.1)} kWh` : '0 kWh'}</p>
                </div>
                <span className="text-[10px] text-slate-500">Power equivalent</span>
              </div>
            </div>
            
            <button 
              id="view-impact-tab-btn"
              onClick={() => onViewChange('Impact')}
              className="w-full mt-5 py-2.5 bg-slate-800 hover:bg-slate-750 text-xs font-semibold text-emerald-400 rounded-xl transition-all flex items-center justify-center gap-1 cursor-pointer border border-emerald-500/20"
            >
              Analyze Environmental Charts &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Leadership & Championship Champions Card */}
      <div id="leader-showcase-grid" className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Top School Card */}
        <div className="bg-white border border-slate-100 p-6 rounded-3xl shadow-xs hover:shadow-md transition-shadow relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-full translate-x-12 -translate-y-12 pointer-events-none" />
          <div className="absolute bottom-4 right-4 text-emerald-100 font-extrabold text-7xl select-none pointer-events-none font-mono">
            #1
          </div>
          
          <div className="relative z-10">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-emerald-100 text-emerald-700 rounded-2xl">
                <SchoolIcon className="w-6 h-6" />
              </div>
              <div>
                <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-md uppercase tracking-wider">Top Performing School</span>
                <h4 id="top-school-name" className="text-lg font-bold text-slate-800 mt-1 lines-clamp-1">{topSchool.name}</h4>
              </div>
            </div>

            <div className="mt-6 flex gap-6 bg-slate-50 p-4 rounded-2xl border border-slate-100 w-fit">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Weight Collected</p>
                <p id="top-school-weight" className="text-xl font-black text-slate-800 mt-1">{topSchool.total.toFixed(1)} kg</p>
              </div>
              <div className="border-l border-slate-200 pl-6">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Est. Performance</p>
                <span className="inline-flex items-center gap-1 text-emerald-600 text-xs font-semibold mt-1">
                  <Award className="w-3.5 h-3.5" /> High Eco-Rate
                </span>
              </div>
            </div>
          </div>

          <button
            id="view-leaderboard-school-btn"
            onClick={() => onViewChange('Leaderboard')}
            className="mt-6 text-xs text-emerald-600 hover:text-emerald-700 font-bold flex items-center gap-1 transition-all cursor-pointer"
          >
            Open School Leaderboard &rarr;
          </button>
        </div>

        {/* Top Pupil Card */}
        <div className="bg-white border border-slate-100 p-6 rounded-3xl shadow-xs hover:shadow-md transition-shadow relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-full translate-x-12 -translate-y-12 pointer-events-none" />
          <div className="absolute bottom-4 right-4 text-indigo-100 font-extrabold text-7xl select-none pointer-events-none font-mono">
            👑
          </div>

          <div className="relative z-10">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-indigo-100 text-indigo-700 rounded-2xl">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 text-[10px] font-bold rounded-md uppercase tracking-wider">Top Performing Student</span>
                <h4 id="top-student-name" className="text-lg font-bold text-slate-800 mt-1 leading-tight truncate">{topStudent.name}</h4>
                <p id="top-student-school" className="text-xs text-slate-400 truncate mt-0.5">{topStudent.school}</p>
              </div>
            </div>

            <div className="mt-6 flex gap-6 bg-slate-50 p-4 rounded-2xl border border-slate-100 w-fit">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Student Weight</p>
                <p id="top-student-weight" className="text-xl font-black text-slate-800 mt-1">{topStudent.total.toFixed(1)} kg</p>
              </div>
              <div className="border-l border-slate-200 pl-6">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Performance Award</p>
                <span className="inline-flex items-center px-2 py-0.5 mt-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full">
                  Excellent Champion
                </span>
              </div>
            </div>
          </div>

          <button
            id="view-leaderboard-student-btn"
            onClick={() => onViewChange('Leaderboard')}
            className="mt-6 text-xs text-indigo-600 hover:text-indigo-700 font-bold flex items-center gap-1 transition-all cursor-pointer"
          >
            Open Student Leaderboard &rarr;
          </button>
        </div>
      </div>
    </div>
  );
}
