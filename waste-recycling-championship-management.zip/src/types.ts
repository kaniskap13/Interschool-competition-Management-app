/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface School {
  id: string; // Auto Generated SCH-001...
  name: string;
  address: string;
  contactPerson: string;
  mobile: string;
  email: string;
  registrationDate: string;
}

export interface Student {
  id: string; // Auto Generated STU-001...
  name: string;
  grade: string; // e.g. "Grade 5", "Grade 6"...
  section: string; // e.g. "A", "B"...
  gender: string; // "Male" | "Female" | "Other"
  schoolId: string; // Foreign key
  schoolName: string; // Denormalized for convenience
  parentMobile: string;
}

export interface CollectionEntry {
  id: string; // Auto Generated ENT-001...
  studentId: string;
  studentName: string;
  schoolId: string;
  schoolName: string;
  collectionDate: string;
  paperWeight: number; // in kg
  plasticWeight: number; // in kg
  totalWeight: number; // calculated: paper + plastic
  performance: 'Excellent' | 'Best' | 'Good' | 'Needs Improvement';
}

export type ViewType =
  | 'Dashboard'
  | 'Schools'
  | 'Students'
  | 'Collections'
  | 'Database'
  | 'Leaderboard'
  | 'Reports'
  | 'Impact';
