/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { School, Student, CollectionEntry, ViewType } from './types';
import { initialSchools, initialStudents, initialEntries } from './mockData';

// Views
import LoginView from './components/LoginView';
import Sidebar from './components/Sidebar';
import DashboardView from './components/DashboardView';
import SchoolsView from './components/SchoolsView';
import StudentsView from './components/StudentsView';
import CollectionsView from './components/CollectionsView';
import DatabaseView from './components/DatabaseView';
import LeaderboardView from './components/LeaderboardView';
import ReportsView from './components/ReportsView';
import ImpactView from './components/ImpactView';

import { Activity, LayoutDashboard, Leaf } from 'lucide-react';
import ConfirmModal from './components/ConfirmModal';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentView, setCurrentView] = useState<ViewType>('Dashboard');

  // Core Database States
  const [schools, setSchools] = useState<School[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [entries, setEntries] = useState<CollectionEntry[]>([]);
  const [loading, setLoading] = useState(true);

  // Custom confirmation modal state
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmLabel?: string;
    onConfirm: () => void;
  } | null>(null);

  // Helper to load data from PostgreSQL server
  const fetchDatabaseData = async () => {
    try {
      const schRes = await fetch('/api/schools');
      if (schRes.ok) {
        setSchools(await schRes.json());
      }
      const stuRes = await fetch('/api/students');
      if (stuRes.ok) {
        setStudents(await stuRes.json());
      }
      const entRes = await fetch('/api/entries');
      if (entRes.ok) {
        setEntries(await entRes.json());
      }
    } catch (err) {
      console.error('Failed to load database data from server, falling back to local storage', err);
    } finally {
      setLoading(false);
    }
  };

  // 1. Load Initial Data or Seed defaults
  useEffect(() => {
    // Auth Check
    const isLogged = localStorage.getItem('rc_admin_logged_in') === 'true';
    setIsLoggedIn(isLogged);

    // Initial database pull from Cloud SQL Postgres!
    fetchDatabaseData();
  }, []);

  // --- Core CRUD Handlers with backend Cloud SQL PostgreSQL persistence ---

  // Schools Handlers
  const handleAddSchool = async (newSchool: School) => {
    try {
      const res = await fetch('/api/schools', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSchool),
      });
      if (res.ok) {
        const result = await res.json();
        setSchools((prev) => [...prev, result]);
      } else {
        console.error('Failed to register school on server');
      }
    } catch (err) {
      console.error('Error adding school', err);
    }
  };

  const handleEditSchool = async (updatedSchool: School) => {
    try {
      const res = await fetch(`/api/schools/${updatedSchool.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedSchool),
      });
      if (res.ok) {
        const result = await res.json();
        setSchools((prev) => prev.map((s) => (s.id === result.id ? result : s)));
        // Refresh to capture cascade changes in students and entries
        await fetchDatabaseData();
      }
    } catch (err) {
      console.error('Error updating school', err);
    }
  };

  const handleDeleteSchool = (id: string) => {
    const schoolObj = schools.find((s) => s.id === id);
    const schoolName = schoolObj ? schoolObj.name : id;
    setConfirmModal({
      isOpen: true,
      title: 'Delete Participating School?',
      message: `Are you sure you want to delete "${schoolName}"? This will cascade-delete all associated student champions and logged recycling deposits from the database permanently.`,
      confirmLabel: 'Confirm Delete',
      onConfirm: async () => {
        try {
          const res = await fetch(`/api/schools/${id}`, {
            method: 'DELETE',
          });
          if (res.ok) {
            setSchools((prev) => prev.filter((s) => s.id !== id));
            await fetchDatabaseData();
          }
        } catch (err) {
          console.error('Error deleting school', err);
        } finally {
          setConfirmModal(null);
        }
      },
    });
  };

  // Students Handlers
  const handleAddStudent = async (newStudent: Student) => {
    try {
      const res = await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newStudent),
      });
      if (res.ok) {
        const result = await res.json();
        setStudents((prev) => [...prev, result]);
      }
    } catch (err) {
      console.error('Error adding student', err);
    }
  };

  const handleEditStudent = async (updatedStudent: Student) => {
    try {
      const res = await fetch(`/api/students/${updatedStudent.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedStudent),
      });
      if (res.ok) {
        const result = await res.json();
        setStudents((prev) => prev.map((s) => (s.id === result.id ? result : s)));
        // Refresh cascade changes
        await fetchDatabaseData();
      }
    } catch (err) {
      console.error('Error updating student', err);
    }
  };

  const handleDeleteStudent = (id: string) => {
    const studentObj = students.find((s) => s.id === id);
    const studentName = studentObj ? studentObj.name : id;
    setConfirmModal({
      isOpen: true,
      title: 'Remove Student Champion?',
      message: `Are you sure you want to delete pupil "${studentName}"? All logged collections registered to this student will be cascade-deleted from the database.`,
      confirmLabel: 'Delete Pupil',
      onConfirm: async () => {
        try {
          const res = await fetch(`/api/students/${id}`, {
            method: 'DELETE',
          });
          if (res.ok) {
            setStudents((prev) => prev.filter((s) => s.id !== id));
            await fetchDatabaseData();
          }
        } catch (err) {
          console.error('Error deleting student', err);
        } finally {
          setConfirmModal(null);
        }
      },
    });
  };

  // Collection Entries Handlers
  const handleAddEntry = async (newEntry: CollectionEntry) => {
    try {
      const res = await fetch('/api/entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEntry),
      });
      if (res.ok) {
        const result = await res.json();
        setEntries((prev) => [...prev, result]);
      }
    } catch (err) {
      console.error('Error adding collection entry', err);
    }
  };

  const handleEditEntry = async (updatedEntry: CollectionEntry) => {
    try {
      const res = await fetch(`/api/entries/${updatedEntry.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedEntry),
      });
      if (res.ok) {
        const result = await res.json();
        setEntries((prev) => prev.map((e) => (e.id === result.id ? result : e)));
      }
    } catch (err) {
      console.error('Error updating collection entry', err);
    }
  };

  const handleDeleteEntry = (id: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Remove Waste Collection Log?',
      message: `Are you sure you want to delete collection record "${id}"? This action cannot be undone.`,
      confirmLabel: 'Delete Log',
      onConfirm: async () => {
        try {
          const res = await fetch(`/api/entries/${id}`, {
            method: 'DELETE',
          });
          if (res.ok) {
            setEntries((prev) => prev.filter((e) => e.id !== id));
          }
        } catch (err) {
          console.error('Error deleting collection entry', err);
        } finally {
          setConfirmModal(null);
        }
      },
    });
  };

  // Auth Handling
  const handleLoginSuccess = () => {
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Sign Out?',
      message: 'Are you sure you want to log out from the system?',
      confirmLabel: 'Sign Out',
      onConfirm: () => {
        localStorage.removeItem('rc_admin_logged_in');
        setIsLoggedIn(false);
        setCurrentView('Dashboard');
        setConfirmModal(null);
      },
    });
  };

  // Router dispatcher
  const renderCurrentView = () => {
    switch (currentView) {
      case 'Dashboard':
        return (
          <DashboardView
            schools={schools}
            students={students}
            entries={entries}
            onViewChange={setCurrentView}
          />
        );
      case 'Schools':
        return (
          <SchoolsView
            schools={schools}
            onAddSchool={handleAddSchool}
            onEditSchool={handleEditSchool}
            onDeleteSchool={handleDeleteSchool}
          />
        );
      case 'Students':
        return (
          <StudentsView
            students={students}
            schools={schools}
            onAddStudent={handleAddStudent}
            onEditStudent={handleEditStudent}
            onDeleteStudent={handleDeleteStudent}
          />
        );
      case 'Collections':
        return (
          <CollectionsView
            entries={entries}
            students={students}
            schools={schools}
            onAddEntry={handleAddEntry}
            onEditEntry={handleEditEntry}
            onDeleteEntry={handleDeleteEntry}
          />
        );
      case 'Database':
        return <DatabaseView entries={entries} students={students} schools={schools} />;
      case 'Leaderboard':
        return <LeaderboardView entries={entries} students={students} schools={schools} />;
      case 'Reports':
        return <ReportsView entries={entries} students={students} schools={schools} />;
      case 'Impact':
        return <ImpactView entries={entries} />;
      default:
        return (
          <DashboardView
            schools={schools}
            students={students}
            entries={entries}
            onViewChange={setCurrentView}
          />
        );
    }
  };

  // Auth Protection guard
  if (!isLoggedIn) {
    return <LoginView onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row font-sans">
      {/* Collapsible/Responsive Sidebar Navigation */}
      <Sidebar
        currentView={currentView}
        onViewChange={setCurrentView}
        onLogout={handleLogout}
      />

      {/* Main Container Viewport */}
      <main className="flex-1 flex flex-col min-w-0">
        
        {/* Top Header Row for Desktop and Tablet */}
        <header className="hidden md:flex bg-white h-16 border-b border-slate-200 sticky top-0 z-30 px-8 items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs bg-emerald-50 text-emerald-800 font-bold px-3 py-1 rounded-full border border-emerald-100 uppercase tracking-widest flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
              Competition Live Period
            </span>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3 border-l border-slate-200 pl-6">
              <div className="text-right">
                <div className="text-xs font-black text-slate-900">Admin Portal</div>
                <div className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider">Championship Mode</div>
              </div>
              <div className="w-10 h-10 rounded-full bg-slate-250 border-2 border-emerald-500 overflow-hidden flex items-center justify-center text-slate-600 font-bold text-sm shadow-sm">
                A
              </div>
            </div>
          </div>
        </header>

        {/* View Layout Page wrapper */}
        <div className="p-4 md:p-8 flex-1 overflow-y-auto max-w-7xl w-full mx-auto pb-20">
          {renderCurrentView()}
        </div>
      </main>

      {/* Confirmation Dialog Modal overlay */}
      {confirmModal && (
        <ConfirmModal
          isOpen={confirmModal.isOpen}
          title={confirmModal.title}
          message={confirmModal.message}
          confirmLabel={confirmModal.confirmLabel}
          onConfirm={confirmModal.onConfirm}
          onCancel={() => setConfirmModal(null)}
        />
      )}
    </div>
  );
}
